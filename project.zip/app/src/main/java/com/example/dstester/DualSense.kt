package com.example.dstester

import android.hardware.usb.*

enum class TMode(val label: String) {
    OFF("Kapalı"), RIGID("Rigid"), PULSE("Pulse"), FEEDBACK("Feedback"),
    WEAPON("Weapon"), BOW("Bow"), GALLOP("Galloping"), MACHINE("Machine"), VIBRATION("Vibration")
}

/** start/end: 0-9 bölge, strength: 1-8, freq: 0-255 */
data class TriggerCfg(
    val mode: TMode = TMode.OFF, val start: Int = 2, val end: Int = 7,
    val strength: Int = 5, val freq: Int = 30
)

class Output {
    var weak = 0; var strong = 0
    var r = 0; var g = 0; var b = 255
    var player = 0; var muteLed = false
    var left = TriggerCfg(); var right = TriggerCfg()
}

data class InputState(
    val lx: Int = 128, val ly: Int = 128, val rx: Int = 128, val ry: Int = 128,
    val l2: Int = 0, val r2: Int = 0,
    val buttons: Set<String> = emptySet(),
    val gyro: IntArray = IntArray(3), val accel: IntArray = IntArray(3),
    val touch: List<Pair<Int, Int>> = emptyList(), // x:0-1919, y:0-1079
    val battery: Int = 0, val charging: String = "", val packets: Int = 0
)

class DualSense private constructor(
    private val conn: UsbDeviceConnection, private val iface: UsbInterface,
    private val inEp: UsbEndpoint, private val outEp: UsbEndpoint?
) {
    companion object {
        fun open(usb: UsbManager, dev: UsbDevice): DualSense? {
            for (i in 0 until dev.interfaceCount) {
                val itf = dev.getInterface(i)
                if (itf.interfaceClass != UsbConstants.USB_CLASS_HID) continue
                var inE: UsbEndpoint? = null; var outE: UsbEndpoint? = null
                for (e in 0 until itf.endpointCount) {
                    val ep = itf.getEndpoint(e)
                    if (ep.direction == UsbConstants.USB_DIR_IN) inE = ep else outE = ep
                }
                if (inE == null) continue
                val c = usb.openDevice(dev) ?: return null
                if (!c.claimInterface(itf, true)) { c.close(); return null }
                return DualSense(c, itf, inE, outE)
            }
            return null
        }

        private fun zones(s: Int, e: Int): Int {
            var m = 0
            for (z in minOf(s, e)..maxOf(s, e)) m = m or (1 shl z)
            return m
        }

        fun triggerBytes(c: TriggerCfg): ByteArray {
            val p = ByteArray(11)
            val z = zones(c.start, c.end)
            val str = (c.strength - 1).coerceIn(0, 7)
            fun set(i: Int, v: Int) { p[i] = v.toByte() }
            when (c.mode) {
                TMode.OFF -> {}
                TMode.RIGID -> { set(0, 0x01); set(1, c.start); set(2, c.strength * 32) }
                TMode.PULSE -> { set(0, 0x02); set(1, c.start); set(2, c.end); set(3, c.strength * 32) }
                TMode.FEEDBACK -> {
                    val active = zones(c.start, 9)
                    var bits = 0L
                    for (i in c.start..9) bits = bits or (str.toLong() shl (3 * i))
                    set(0, 0x21); set(1, active and 0xFF); set(2, active shr 8)
                    for (k in 0..3) set(3 + k, ((bits shr (8 * k)) and 0xFF).toInt())
                }
                TMode.WEAPON -> { set(0, 0x25); set(1, z and 0xFF); set(2, z shr 8); set(3, str) }
                TMode.BOW -> { set(0, 0x22); set(1, z and 0xFF); set(2, z shr 8); set(3, str or (str shl 3)) }
                TMode.GALLOP -> {
                    set(0, 0x23); set(1, z and 0xFF); set(2, z shr 8)
                    set(3, 2 or (4 shl 3)); set(4, c.freq)
                }
                TMode.MACHINE -> {
                    set(0, 0x27); set(1, z and 0xFF); set(2, z shr 8)
                    set(3, str or (str shl 3)); set(4, c.freq); set(5, 0x08)
                }
                TMode.VIBRATION -> {
                    val active = zones(c.start, 9)
                    var bits = 0L
                    for (i in c.start..9) bits = bits or (str.toLong() shl (3 * i))
                    set(0, 0x26); set(1, active and 0xFF); set(2, active shr 8)
                    for (k in 0..3) set(3 + k, ((bits shr (8 * k)) and 0xFF).toInt())
                    set(10, c.freq)
                }
            }
            return p
        }
    }

    @Synchronized
    fun send(o: Output) {
        val b = ByteArray(63)
        b[0] = 0x02
        b[1] = 0x0F                      // rumble + sağ/sol trigger
        b[2] = (0x01 or 0x04 or 0x10).toByte() // mic LED + lightbar + player LED
        b[3] = o.weak.toByte(); b[4] = o.strong.toByte()
        b[9] = if (o.muteLed) 1 else 0
        triggerBytes(o.right).copyInto(b, 11)
        triggerBytes(o.left).copyInto(b, 22)
        b[44] = o.player.toByte()
        b[45] = o.r.toByte(); b[46] = o.g.toByte(); b[47] = o.b.toByte()
        if (outEp != null) conn.bulkTransfer(outEp, b, b.size, 100)
        else conn.controlTransfer(0x21, 0x09, 0x0202, iface.id, b, b.size, 100)
    }

    fun readLoop(alive: () -> Boolean, onState: (InputState) -> Unit) {
        val buf = ByteArray(64); var count = 0
        while (alive()) {
            val n = conn.bulkTransfer(inEp, buf, buf.size, 100)
            if (n >= 54 && buf[0] == 0x01.toByte()) onState(parse(buf, ++count))
        }
    }

    private fun parse(d: ByteArray, count: Int): InputState {
        fun u(i: Int) = d[i].toInt() and 0xFF
        fun s(i: Int) = (u(i) or (u(i + 1) shl 8)).toShort().toInt()
        val btn = mutableSetOf<String>()
        val b8 = u(8); val b9 = u(9); val b10 = u(10)
        listOf("□" to 0x10, "✕" to 0x20, "○" to 0x40, "△" to 0x80).forEach { if (b8 and it.second != 0) btn += it.first }
        listOf("L1" to 0x01, "R1" to 0x02, "L2" to 0x04, "R2" to 0x08, "Create" to 0x10,
            "Options" to 0x20, "L3" to 0x40, "R3" to 0x80).forEach { if (b9 and it.second != 0) btn += it.first }
        listOf("PS" to 0x01, "Touchpad" to 0x02, "Mute" to 0x04).forEach { if (b10 and it.second != 0) btn += it.first }
        listOf("↑", "↗", "→", "↘", "↓", "↙", "←", "↖").getOrNull(b8 and 0x0F)?.let { btn += it }
        val touch = (0..1).mapNotNull { i ->
            val o = 33 + i * 4
            if (u(o) and 0x80 != 0) null
            else (u(o + 1) or ((u(o + 2) and 0x0F) shl 8)) to ((u(o + 2) shr 4) or (u(o + 3) shl 4))
        }
        val st = u(53)
        return InputState(
            u(1), u(2), u(3), u(4), u(5), u(6), btn,
            intArrayOf(s(16), s(18), s(20)), intArrayOf(s(22), s(24), s(26)),
            touch, minOf((st and 0x0F) * 10 + 5, 100),
            when (st shr 4) { 1 -> "Şarj oluyor"; 2 -> "Dolu"; else -> "Pilde" }, count
        )
    }

    fun close() { try { conn.releaseInterface(iface); conn.close() } catch (_: Exception) {} }
}
