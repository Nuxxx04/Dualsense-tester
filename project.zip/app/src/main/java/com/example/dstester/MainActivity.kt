@file:OptIn(ExperimentalLayoutApi::class)
package com.example.dstester

import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

private val BG = Color(0xFF05070B)
private val CardC = Color(0xFF111723)
private val Edge = Color(0xFF1C2433)
private val ChipC = Color(0xFF1A2232)
private val Muted = Color(0xFF8B93A5)
private val Ok = Color(0xFF22C55E)
private val Rose = Color(0xFFF43F5E)
private val BlueC = Color(0xFF3B82F6)
private val Violet = Color(0xFFA855F7)

class MainActivity : ComponentActivity() {
    private val ACTION = "com.example.dstester.USB_PERMISSION"
    private var ds by mutableStateOf<DualSense?>(null)
    private var status by mutableStateOf("Kablo bekleniyor")

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == UsbManager.ACTION_USB_DEVICE_DETACHED) {
                ds?.close(); ds = null; status = "Kontrolcü çıkarıldı"
            } else connect()
        }
    }

    private fun connect() {
        val um = getSystemService(USB_SERVICE) as UsbManager
        val d = um.deviceList.values.firstOrNull {
            it.vendorId == 0x054C && (it.productId == 0x0CE6 || it.productId == 0x0DF2)
        } ?: return
        if (!um.hasPermission(d)) {
            val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION).setPackage(packageName), PendingIntent.FLAG_MUTABLE)
            um.requestPermission(d, pi); return
        }
        ds?.close()
        ds = DualSense.open(um, d)
        status = if (ds != null) "${d.productName ?: "DualSense"} · USB-C" else "USB arayüzü açılamadı"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = IntentFilter(ACTION).apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED); addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        connect()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = BG, primary = Color.White)) {
                Surface(color = BG) { App(ds, status) }
            }
        }
    }

    override fun onDestroy() { unregisterReceiver(receiver); ds?.close(); super.onDestroy() }
}

// ---------- Ortak bileşenler ----------
@Composable
fun T(text: String, size: Int = 14, color: Color = Color.White, bold: Boolean = false,
      mono: Boolean = false, spacing: Float = 0f, modifier: Modifier = Modifier) {
    Text(text, modifier, color = color, fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default, letterSpacing = spacing.sp)
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(16.dp)
    Column(modifier.fillMaxWidth().clip(sh).background(CardC).border(1.dp, Edge, sh).padding(16.dp), content = content)
}

@Composable
fun Section(title: String, sub: String) {
    Column(Modifier.padding(top = 20.dp, bottom = 10.dp)) { T(title, 20, bold = true); T(sub, 12, Muted) }
}

@Composable
fun Stat(label: String, value: String, unit: String, modifier: Modifier) {
    Panel(modifier) {
        T(label.uppercase(), 11, Muted, spacing = 1f); Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            T(value, 30, bold = true)
            if (unit.isNotEmpty()) T(unit, 13, Muted, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
        }
    }
}

@Composable
fun SmallBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val sh = RoundedCornerShape(20.dp)
    Box(modifier.clip(sh).background(Color(0xFF10233F)).border(1.dp, Color(0xFF4A6FA5), sh)
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {
        T(text.uppercase(), 11, bold = true, spacing = 1f)
    }
}

@Composable
fun Pill(text: String, color: Color = Color.White) {
    val sh = RoundedCornerShape(20.dp)
    Box(Modifier.clip(sh).border(1.dp, color, sh).padding(horizontal = 12.dp, vertical = 6.dp)) {
        T(text, 11, color, bold = true, spacing = 1f)
    }
}

@Composable
fun WSlider(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        T(label.uppercase(), 11, Muted, spacing = 1f); T("$value", 13, bold = true)
    }
    Slider(value.toFloat(), { onChange(it.toInt()) }, valueRange = range.first.toFloat()..range.last.toFloat(),
        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White,
            inactiveTrackColor = Color(0xFF1F2937)))
}

@Composable
fun Key(text: String, on: Boolean, c: Color = Color.White, w: Int = 52) {
    val sh = RoundedCornerShape(12.dp)
    val plain = c == Color.White
    Box(Modifier.size(w.dp, 46.dp).clip(sh).background(if (on) c else ChipC)
        .border(1.dp, if (on) c else if (plain) Edge else c.copy(alpha = 0.6f), sh), contentAlignment = Alignment.Center) {
        T(text, 14, if (on) Color.Black else if (plain) Color.White else c, true)
    }
}

@Composable
fun Cap(text: String) { Spacer(Modifier.height(14.dp)); T(text, 10, Muted, bold = true, spacing = 1.5f); Spacer(Modifier.height(8.dp)) }

@Composable
fun Title(title: String, sub: String) {
    Column(Modifier.padding(top = 8.dp)) { T(title, 24, bold = true, spacing = 1.5f); T(sub, 12, Muted) }
}

fun pulse(ds: DualSense?, o: Output, left: Boolean, both: Boolean = false) {
    Thread {
        if (left || both) o.strong = 255
        if (!left || both) o.weak = 255
        ds?.send(o); Thread.sleep(600)
        o.strong = 0; o.weak = 0
        ds?.send(o)
    }.start()
}

// ---------- Ana ekran ----------
@Composable
fun App(ds: DualSense?, status: String) {
    var state by remember { mutableStateOf(InputState()) }
    val out = remember { Output() }
    var tab by remember { mutableIntStateOf(0) }
    var hz by remember { mutableIntStateOf(0) }
    var yaw by remember { mutableFloatStateOf(0f) }
    var bias by remember { mutableIntStateOf(0) }
    var testRun by remember { mutableIntStateOf(0) }
    var report by remember { mutableStateOf(false) }
    var jack by remember { mutableStateOf(false) }
    val trail = remember { mutableStateListOf<Offset>() }
    fun push() { ds?.let { d -> Thread { d.send(out) }.start() } }

    LaunchedEffect(ds) {
        ds?.let { d ->
            var lastT = 0L
            withContext(Dispatchers.IO) {
                d.readLoop({ isActive }) { s ->
                    state = s
                    val now = System.nanoTime()
                    if (lastT != 0L) {
                        val dt = ((now - lastT) / 1e9f).coerceAtMost(0.1f)
                        var y = yaw + (s.gyro[2] - bias) / 1024f * dt
                        if (y > 180f) y -= 360f; if (y < -180f) y += 360f
                        yaw = y
                    }
                    lastT = now
                    s.touch.forEach { (x, y) -> trail.add(Offset(x / 1920f, y / 1080f)); if (trail.size > 150) trail.removeAt(0) }
                }
            }
        }
    }
    LaunchedEffect(ds) {
        var last = 0
        while (true) { delay(1000); val p = state.packets; hz = if (p >= last) p - last else 0; last = p }
    }
    LaunchedEffect(ds) { push() }

    Scaffold(containerColor = BG, bottomBar = {
        NavigationBar(containerColor = BG) {
            listOf("▦" to "Panel", "🎮" to "Giriş", "📳" to "Geri Bildirim", "⟁" to "Sensörler").forEachIndexed { i, (ic, t) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Text(ic, fontSize = 20.sp) }, label = { Text(t, fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(selectedTextColor = Color.White, unselectedTextColor = Muted,
                        indicatorColor = Color(0xFF1F2937)))
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            when (tab) {
                0 -> DashTab(ds, state, out, hz, status, testRun, { testRun++; pulse(ds, out, true, true) }, { report = true })
                1 -> InputTab(state, trail)
                2 -> FeedbackTab(ds, out, ::push)
                else -> SensorTab(ds, state, out, yaw, jack, { jack = !jack }, { yaw = 0f; bias = state.gyro[2] })
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (report) AlertDialog(onDismissRequest = { report = false }, confirmButton = {
        TextButton({ report = false }) { Text("Kapat") }
    }, title = { Text("Test Raporu") }, text = {
        val s = state
        Text("Bağlantı: $status\nPil: %${s.battery} (${s.charging})\nPolling: $hz Hz\nPaket: ${s.packets}\n" +
            "Jiroskop: ${s.gyro.joinToString(", ")}\nİvme: ${s.accel.joinToString(", ")}\n" +
            "Basılı tuşlar: ${s.buttons.joinToString(" ").ifEmpty { "—" }}\nDokunmatik: ${s.touch.size}/2 parmak",
            fontFamily = FontFamily.Monospace, fontSize = 12.sp)
    })
}

// ---------- Panel ----------
@Composable
fun DashTab(ds: DualSense?, s: InputState, o: Output, hz: Int, status: String, run: Int, rerun: () -> Unit, report: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        T("▮▮ DUALSENSE", 18, bold = true, spacing = 1.5f, modifier = Modifier.weight(1f))
        Pill("PİL %${s.battery}"); Spacer(Modifier.width(8.dp)); Pill(if (ds != null) "USB BAĞLI" else "YOK")
    }
    Spacer(Modifier.height(16.dp))
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color.White).clickable(onClick = report)
        .padding(vertical = 16.dp), contentAlignment = Alignment.Center) { T("RAPOR OLUŞTUR", 14, Color.Black, true, spacing = 1f) }
    Section("Performans", "Canlı telemetri")
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("Gecikme", if (hz > 0) "${1000 / hz}" else "—", "ms", Modifier.weight(1f))
        Stat("Polling", "$hz", "Hz", Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("Pil", "${s.battery}", "%", Modifier.weight(1f))
        Stat("Güç", if (s.charging == "Pilde") "PİL" else "USB", "", Modifier.weight(1f))
    }
    Section("Bağlantı", "")
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🔌", fontSize = 22.sp); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { T("USB-C (OTG)", 16, bold = true); T(status, 12, Muted) }
            Pill(if (ds != null) "AKTİF" else "YOK")
        }
    }
    Section("Sistem", "Donanım kancaları")
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("♥ KENDİ KENDİNİ TEST", 13, bold = true, spacing = 1f, modifier = Modifier.weight(1f))
            SmallBtn("Tekrar", onClick = rerun)
        }
        val anyG = s.gyro.any { it != 0 }; val anyA = s.accel.any { it != 0 }
        listOf("Jiroskop" to anyG, "İvmeölçer" to anyA, "Pil API" to (s.battery > 0),
            "Haptik Motor" to (ds != null)).forEach { (n, pass) ->
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                T(n, 14, Color(0xFFD1D5DB), modifier = Modifier.weight(1f))
                T(if (pass) "✔ GEÇTİ" else "… BEKLİYOR", 12, if (pass) Color.White else Muted, true)
            }
        }
    }
}

// ---------- Giriş ----------
@Composable
fun InputTab(s: InputState, trail: SnapshotStateList<Offset>) {
    Title("GİRİŞ MATRİSİ", "Canlı · Tuşlar · Çubuklar · Dokunmatik")
    Section("Tuşlar ve Giriş Matrisi", "")
    val b = s.buttons
    fun has(vararg k: String) = k.any { it in b }
    Panel {
        T("YÖN TUŞLARI", 10, Muted, true, spacing = 1.5f); Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Key("▲", has("↑", "↗", "↖"))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Key("◀", has("←", "↙", "↖")); Spacer(Modifier.width(52.dp)); Key("▶", has("→", "↗", "↘"))
            }
            Key("▼", has("↓", "↘", "↙"))
        }
        Cap("YÜZ TUŞLARI")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Key("△", "△" in b, Ok); Key("○", "○" in b, Rose); Key("✕", "✕" in b, BlueC); Key("□", "□" in b, Violet)
        }
        Cap("OMUZ / TETİK")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Key("L1", "L1" in b); Key("R1", "R1" in b); Key("L2", "L2" in b); Key("R2", "R2" in b)
        }
        Cap("YARDIMCI")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Key("CRE", "Create" in b); Key("OPT", "Options" in b); Key("PS", "PS" in b); Key("MİK", "Mute" in b)
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(ChipC).padding(12.dp)) {
            T("◯ Eş zamanlı tuş: ${b.count { it.length > 1 || it in listOf("△", "○", "✕", "□") }} aktif", 13, Color(0xFFD1D5DB))
        }
    }
    Section("Analog Çubuklar", "L3 / R3")
    Panel {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stick("L3", s.lx, s.ly, "L3" in b); Stick("R3", s.rx, s.ry, "R3" in b)
        }
    }
    Section("Tetikler", "Analog değer")
    Panel {
        listOf("L2" to s.l2, "R2" to s.r2).forEach { (n, v) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T(n, 12, Muted, true); T("$v", 12, bold = true, mono = true)
            }
            LinearProgressIndicator({ v / 255f }, Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                Color.White, Color(0xFF1F2937)); Spacer(Modifier.height(10.dp))
        }
    }
    Section("Dokunmatik Yüzey", "2 parmaklı çoklu dokunma")
    Panel {
        Box(Modifier.fillMaxWidth().aspectRatio(320f / 220f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF0B0F17)),
            contentAlignment = Alignment.Center) {
            Canvas(Modifier.matchParentSize()) {
                trail.forEachIndexed { i, p ->
                    drawCircle(Color.White.copy(alpha = 0.15f + 0.6f * i / trail.size.coerceAtLeast(1)), 5f,
                        Offset(p.x * size.width, p.y * size.height))
                }
                s.touch.forEach { (x, y) -> drawCircle(Color.White, 16f, Offset(x / 1920f * size.width, y / 1080f * size.height)) }
            }
            if (trail.isEmpty()) T("1-2 PARMAKLA SÜRÜKLE", 12, Muted, true, spacing = 1f)
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Parmak: ${s.touch.size}/2 · Boyut: 1920×1080", 12, Muted, modifier = Modifier.weight(1f))
            SmallBtn("Temizle") { trail.clear() }
        }
    }
}

@Composable
fun Stick(label: String, x: Int, y: Int, pressed: Boolean) {
    val nx = (x - 128) / 127f; val ny = (y - 128) / 127f
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(120.dp)) {
            val r = size.minDimension / 2
            drawCircle(Color(0xFF1F2937), r, style = Stroke(3f))
            drawLine(Color(0xFF1F2937), Offset(0f, r), Offset(size.width, r), 2f)
            drawLine(Color(0xFF1F2937), Offset(r, 0f), Offset(r, size.height), 2f)
            drawCircle(if (pressed) Ok else Color.White, 14f, Offset(r + nx * (r - 14f), r + ny * (r - 14f)))
        }
        T(label, 16, bold = true)
        T("X %.2f  Y %.2f".format(nx, ny), 11, Muted, mono = true)
        T(if (abs(nx) < 0.1f && abs(ny) < 0.1f) "ORTADA" else "AKTİF", 11, bold = true, spacing = 1f)
    }
}

// ---------- Geri bildirim ----------
@Composable
fun FeedbackTab(ds: DualSense?, o: Output, push: () -> Unit) {
    Title("GERİ BİLDİRİM", "Tetikler · Haptik · Aydınlatma")
    Section("Adaptif Tetikler", "L2 / R2")
    Panel {
        TriggerPanel("L2 tetik modu", o.left) { o.left = it; push() }
        Spacer(Modifier.height(16.dp))
        TriggerPanel("R2 tetik modu", o.right) { o.right = it; push() }
    }
    Section("Haptik Geri Bildirim", "Çift voice-coil eyleyici")
    Panel {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f)) { T("SOL MOTOR", 10, Muted, true, spacing = 1.5f); Segments(o.strong) }
            Column(Modifier.weight(1f)) { T("SAĞ MOTOR", 10, Muted, true, spacing = 1.5f); Segments(o.weak) }
        }
        Spacer(Modifier.height(8.dp))
        WSlider("Sol motor (güçlü)", o.strong, 0..255) { o.strong = it; push() }
        WSlider("Sağ motor (hafif)", o.weak, 0..255) { o.weak = it; push() }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallBtn("Sol test", Modifier.weight(1f)) { pulse(ds, o, true) }
            SmallBtn("Sağ test", Modifier.weight(1f)) { pulse(ds, o, false) }
        }
        Spacer(Modifier.height(8.dp))
        SmallBtn("Eski titreşim testi", Modifier.fillMaxWidth()) { pulse(ds, o, true, true) }
        Spacer(Modifier.height(8.dp))
        SmallBtn("Durdur", Modifier.fillMaxWidth()) { o.strong = 0; o.weak = 0; push() }
    }
    Section("RGB Lightbar", "Çift lightbar renk kontrolü")
    Panel {
        Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(14.dp)).background(Color(o.r, o.g, o.b)),
            contentAlignment = Alignment.Center) {
            val dark = (o.r * 0.3 + o.g * 0.6 + o.b * 0.1) > 150
            T("RGB(${o.r}, ${o.g}, ${o.b})", 16, if (dark) Color.Black else Color.White, true, mono = true)
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf(Triple(0, 112, 243), Triple(255, 59, 108), Triple(0, 230, 122), Triple(245, 158, 11),
                Triple(224, 102, 255), Triple(0, 224, 255), Triple(255, 255, 255)).forEach { (r, g, b) ->
                Box(Modifier.size(38.dp).clip(CircleShape).background(Color(r, g, b)).clickable {
                    o.r = r; o.g = g; o.b = b; push()
                })
            }
        }
        Spacer(Modifier.height(10.dp))
        WSlider("Kırmızı", o.r, 0..255) { o.r = it; push() }
        WSlider("Yeşil", o.g, 0..255) { o.g = it; push() }
        WSlider("Mavi", o.b, 0..255) { o.b = it; push() }
    }
    Section("Oyuncu LED'leri", "5 ayrı LED")
    Panel {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            (0..4).forEach { i ->
                val on = (o.player shr i) and 1 == 1
                Box(Modifier.size(46.dp).clip(CircleShape).background(if (on) Color(0xFF1F2937) else Color(0xFF0B0F17))
                    .border(2.dp, if (on) Color.White else Edge, CircleShape)
                    .clickable { o.player = o.player xor (1 shl i); push() }, contentAlignment = Alignment.Center) {
                    if (on) Box(Modifier.size(16.dp).clip(CircleShape).background(Color.White))
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { T("Dokun: aç/kapat · P1 - P5", 11, Muted) }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Mikrofon LED", 14, modifier = Modifier.weight(1f)); Switch(o.muteLed, { o.muteLed = it; push() })
        }
    }
}

@Composable
fun Segments(level: Int) {
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth().height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(16) { i ->
            Box(Modifier.weight(1f).fillMaxHeight().background(if (level * 16 / 256 > i) Color.White else Color(0xFF1F2937)))
        }
    }
}

@Composable
fun TriggerPanel(title: String, c: TriggerCfg, onChange: (TriggerCfg) -> Unit) {
    T(title.uppercase(), 10, Muted, true, spacing = 1.5f); Spacer(Modifier.height(8.dp))
    val names = mapOf(TMode.OFF to "Kapalı", TMode.RIGID to "Sert", TMode.PULSE to "Darbe", TMode.FEEDBACK to "Geri Besleme",
        TMode.WEAPON to "Silah", TMode.BOW to "Yay", TMode.GALLOP to "Dörtnala", TMode.MACHINE to "Makine", TMode.VIBRATION to "Titreşim")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TMode.values().forEach { m ->
            val on = c.mode == m
            Box(Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Color.White else ChipC)
                .clickable { onChange(c.copy(mode = m)) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                T(names[m] ?: m.label, 13, if (on) Color.Black else Color(0xFFD1D5DB), true)
            }
        }
    }
    Cap("ÖZEL PARAMETRELER")
    WSlider("Direnç (1-8)", c.strength, 1..8) { onChange(c.copy(strength = it)) }
    WSlider("Başlangıç bölgesi", c.start, 0..9) { onChange(c.copy(start = it)) }
    WSlider("Bitiş bölgesi", c.end, 0..9) { onChange(c.copy(end = it)) }
    WSlider("Frekans", c.freq, 0..255) { onChange(c.copy(freq = it)) }
}

// ---------- Sensörler ----------
@Composable
fun SensorTab(ds: DualSense?, s: InputState, o: Output, yaw: Float, jack: Boolean, toggleJack: () -> Unit, calibrate: () -> Unit) {
    Title("SENSÖRLER", "Hareket · Ses · Güç")
    val ax = s.accel[0] / 8192f; val ay = s.accel[1] / 8192f; val az = s.accel[2] / 8192f
    val roll = Math.toDegrees(atan2(ax.toDouble(), ay.toDouble())).toFloat()
    val pitch = Math.toDegrees(atan2(az.toDouble(), sqrt((ax * ax + ay * ay).toDouble()))).toFloat()
    Section("6 Eksenli Hareket", "Canlı cihaz yönü")
    Panel {
        Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(130.dp).rotate(roll).clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B3D91))
                .border(3.dp, Color.White, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                T("DS5", 24, Color(0xFF93B4E8), true)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("EĞİM" to pitch, "YUVARLANMA" to roll, "SAPMA" to yaw).forEach { (n, v) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    T(n, 10, Muted, true, spacing = 1.5f); T("%.1f°".format(v), 20, bold = true)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        SmallBtn("◎ Kalibre et", Modifier.fillMaxWidth(), calibrate)
    }
    Section("Ham Telemetri", "")
    Panel {
        TelRow("⟲ JİROSKOP (°/s)", s.gyro.map { it / 1024f })
        Spacer(Modifier.height(16.dp))
        TelRow("⟁ İVMEÖLÇER (g)", listOf(ax, ay, az))
    }
    Section("Ses G/Ç", "Hoparlör · 3.5mm jak")
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🔊", fontSize = 22.sp); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { T("Dahili Hoparlör", 15, bold = true); T("Voice-coil eyleyici testi", 12, Muted) }
            SmallBtn("Test") { pulse(ds, o, true, true) }
        }
        Spacer(Modifier.height(18.dp))
        val plugged = jack || (s.status2 and 0x01) != 0
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🎧", fontSize = 22.sp); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { T("3.5mm Jak", 15, bold = true); T(if (plugged) "Kulaklık algılandı" else "Cihaz yok", 12, Muted) }
            SmallBtn("Simüle", onClick = toggleJack)
        }
    }
    Section("Güç", "Pil tanılama")
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("Seviye", "${s.battery}", "%", Modifier.weight(1f))
        Stat("Durum", when (s.charging) { "Şarj oluyor" -> "ŞARJ"; "Dolu" -> "DOLU"; else -> "PİL" }, "", Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("Tüketim", "—", "W", Modifier.weight(1f))
        Stat("Voltaj (tahmini)", "%.2f".format(3.2f + s.battery / 100f), "V", Modifier.weight(1f))
    }
}

@Composable
fun TelRow(title: String, v: List<Float>) {
    T(title, 12, bold = true, spacing = 1f); Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        listOf("X", "Y", "Z").forEachIndexed { i, n ->
            Row { T("$n ", 12, Muted, true); T("%.3f".format(v[i]), 13, bold = true, mono = true) }
        }
    }
}
