package com.example.dstester

import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    private val ACTION = "com.example.dstester.USB_PERMISSION"
    private var ds by mutableStateOf<DualSense?>(null)
    private var status by mutableStateOf("Kontrolcü bağlı değil — OTG ile USB kablo takın")

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == UsbManager.ACTION_USB_DEVICE_DETACHED) {
                ds?.close(); ds = null; status = "Kontrolcü çıkarıldı"
            } else connect()
        }
    }

    private fun connect() {
        val um = getSystemService(USB_SERVICE) as UsbManager
        val d = um.deviceList.values.firstOrNull {
            it.vendorId == 0x054C && (it.productId == 0x0CE6 || it.productId == 0x0DF2)
        } ?: return
        if (!um.hasPermission(d)) {
            val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION).setPackage(packageName), PendingIntent.FLAG_MUTABLE)
            um.requestPermission(d, pi); return
        }
        ds?.close()
        ds = DualSense.open(um, d)
        status = if (ds != null) "Bağlandı: ${d.productName ?: "DualSense"}" else "USB arayüzü açılamadı"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = IntentFilter(ACTION).apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED); addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        connect()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App(ds, status) } } }
    }

    override fun onDestroy() { unregisterReceiver(receiver); ds?.close(); super.onDestroy() }
}

@Composable
fun Sl(label: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Text("$label: ${v.toInt()}")
    Slider(v, onChange, valueRange = range)
}

@Composable
fun App(ds: DualSense?, status: String) {
    var state by remember { mutableStateOf(InputState()) }
    val out = remember { Output() }
    var tab by remember { mutableIntStateOf(0) }
    fun push() { ds?.let { d -> Thread { d.send(out) }.start() } }

    LaunchedEffect(ds) {
        ds?.let { d -> withContext(Dispatchers.IO) { d.readLoop({ isActive }) { state = it } } }
    }
    LaunchedEffect(ds) { push() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(status, Modifier.padding(12.dp), style = MaterialTheme.typography.titleSmall)
        ScrollableTabRow(tab) {
            listOf("Girişler", "Trigger", "Işık/Titreşim", "Sensör").forEachIndexed { i, t ->
                Tab(tab == i, { tab = i }) { Text(t, Modifier.padding(12.dp)) }
            }
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
            when (tab) {
                0 -> InputsTab(state)
                1 -> {
                    TriggerPanel("Sol trigger (L2)") { out.left = it; push() }
                    Spacer(Modifier.height(16.dp))
                    TriggerPanel("Sağ trigger (R2)") { out.right = it; push() }
                }
                2 -> LightTab(out, ::push)
                else -> SensorTab(state)
            }
        }
    }
}

@Composable
fun InputsTab(s: InputState) {
    Text("Basılı: " + s.buttons.joinToString("  ").ifEmpty { "—" })
    Text("Sol çubuk: ${s.lx}, ${s.ly}   Sağ çubuk: ${s.rx}, ${s.ry}")
    Text("L2: ${s.l2}"); LinearProgressIndicator(progress = { s.l2 / 255f }, Modifier.fillMaxWidth())
    Text("R2: ${s.r2}"); LinearProgressIndicator(progress = { s.r2 / 255f }, Modifier.fillMaxWidth())
    Text("Pil: %${s.battery} · ${s.charging} · paket: ${s.packets}")
    Spacer(Modifier.height(8.dp)); Text("Dokunmatik yüzey")
    Canvas(Modifier.fillMaxWidth().aspectRatio(1920f / 1080f)) {
        drawRect(Color.DarkGray)
        s.touch.forEachIndexed { i, (x, y) ->
            drawCircle(if (i == 0) Color.Cyan else Color.Magenta, 24f,
                Offset(x / 1920f * size.width, y / 1080f * size.height))
        }
    }
}

@Composable
fun SensorTab(s: InputState) {
    Text("Gyro (ham)"); listOf("X", "Y", "Z").forEachIndexed { i, n ->
        Text("$n: ${s.gyro[i]}"); LinearProgressIndicator(progress = { (s.gyro[i] + 32768) / 65535f }, Modifier.fillMaxWidth())
    }
    Spacer(Modifier.height(12.dp)); Text("İvmeölçer (ham)"); listOf("X", "Y", "Z").forEachIndexed { i, n ->
        Text("$n: ${s.accel[i]}"); LinearProgressIndicator(progress = { (s.accel[i] + 32768) / 65535f }, Modifier.fillMaxWidth())
    }
}

@Composable
fun LightTab(o: Output, push: () -> Unit) {
    var r by remember { mutableFloatStateOf(0f) }; var g by remember { mutableFloatStateOf(0f) }
    var b by remember { mutableFloatStateOf(255f) }; var w by remember { mutableFloatStateOf(0f) }
    var st by remember { mutableFloatStateOf(0f) }; var mute by remember { mutableStateOf(false) }
    var pl by remember { mutableIntStateOf(0) }
    Text("Lightbar", style = MaterialTheme.typography.titleMedium)
    Sl("Kırmızı", r, 0f..255f) { r = it; o.r = it.toInt(); push() }
    Sl("Yeşil", g, 0f..255f) { g = it; o.g = it.toInt(); push() }
    Sl("Mavi", b, 0f..255f) { b = it; o.b = it.toInt(); push() }
    Text("Player LED", style = MaterialTheme.typography.titleMedium)
    Row { (0..4).forEach { i ->
        Checkbox((pl shr i) and 1 == 1, { pl = pl xor (1 shl i); o.player = pl; push() })
    } }
    Row { Text("Mikrofon LED"); Switch(mute, { mute = it; o.muteLed = it; push() }) }
    Spacer(Modifier.height(12.dp)); Text("Titreşim motorları", style = MaterialTheme.typography.titleMedium)
    Sl("Sol (güçlü)", st, 0f..255f) { st = it; o.strong = it.toInt(); push() }
    Sl("Sağ (hafif)", w, 0f..255f) { w = it; o.weak = it.toInt(); push() }
    Button({ st = 0f; w = 0f; o.strong = 0; o.weak = 0; push() }) { Text("Titreşimi durdur") }
}

@Composable
fun TriggerPanel(title: String, onChange: (TriggerCfg) -> Unit) {
    var c by remember { mutableStateOf(TriggerCfg()) }
    fun up(n: TriggerCfg) { c = n; onChange(n) }
    Text(title, style = MaterialTheme.typography.titleMedium)
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        TMode.values().forEach { m -> FilterChip(c.mode == m, { up(c.copy(mode = m)) }, { Text(m.label) }, Modifier.padding(end = 6.dp)) }
    }
    Sl("Başlangıç bölgesi (0-9)", c.start.toFloat(), 0f..9f) { up(c.copy(start = it.toInt())) }
    Sl("Bitiş bölgesi (0-9)", c.end.toFloat(), 0f..9f) { up(c.copy(end = it.toInt())) }
    Sl("Kuvvet (1-8)", c.strength.toFloat(), 1f..8f) { up(c.copy(strength = it.toInt())) }
    Sl("Frekans (0-255)", c.freq.toFloat(), 0f..255f) { up(c.copy(freq = it.toInt())) }
}
