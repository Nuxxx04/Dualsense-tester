package com.example.dstester

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.*

/** Yüzey türü: renk çizim anında belirlenir (ışık çubuğu kolun gerçek rengini alır). */
enum class Part { SHELL, SHELL_SIDE, PLATE, TOUCH, STICK, STICK_TOP, BUTTON, SYMBOL_G, SYMBOL_R, SYMBOL_B, SYMBOL_P, LIGHT, DARK }

class Poly(val v: Array<FloatArray>, val part: Part, val n: FloatArray) {
    /** Gövdenin üstünde duran parça (çubuk, tuş, panel): gövdenin üstü görünmüyorsa çizilmez. */
    val onTop = part != Part.SHELL && v.all { it[1] >= 0.199f }
}

/**
 * DualSense'e benzeyen 3B model (birim: x sağ, y yukarı, z oyuncuya doğru). Bir kez kurulur;
 * her karede yalnızca döndürülüp boyanır (yaklaşık 220 yüz, telefonda akıcı).
 */
object PadModel {
    val polys: List<Poly> by lazy { build() }

    private fun outline(): List<FloatArray> {
        // Sağ yarı (üstten bakış), ortadan saat yönünde; sola aynalanır.
        val right = listOf(0f to -0.86f, 0.62f to -0.86f, 1.06f to -0.80f, 1.36f to -0.62f, 1.52f to -0.33f, 1.6f to 0.02f, 1.65f to 0.38f,
            1.68f to 0.72f, 1.63f to 1.02f, 1.5f to 1.24f, 1.3f to 1.32f, 1.1f to 1.22f, 0.96f to 0.96f, 0.8f to 0.64f, 0.55f to 0.5f, 0f to 0.5f)
        val pts = right + right.drop(1).dropLast(1).reversed().map { (-it.first) to it.second }
        // Catmull-Rom ile yumuşat
        val out = ArrayList<FloatArray>()
        val n = pts.size
        for (i in 0 until n) {
            val p0 = pts[(i - 1 + n) % n]; val p1 = pts[i]; val p2 = pts[(i + 1) % n]; val p3 = pts[(i + 2) % n]
            for (k in 0 until 4) {
                val t = k / 4f; val t2 = t * t; val t3 = t2 * t
                fun cr(a: Float, b: Float, c: Float, d: Float) = 0.5f * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3)
                out += floatArrayOf(cr(p0.first, p1.first, p2.first, p3.first), cr(p0.second, p1.second, p2.second, p3.second))
            }
        }
        return out
    }

    private fun newell(v: Array<FloatArray>): FloatArray {
        var x = 0f; var y = 0f; var z = 0f
        for (i in v.indices) { val a = v[i]; val b = v[(i + 1) % v.size]; x += (a[1] - b[1]) * (a[2] + b[2]); y += (a[2] - b[2]) * (a[0] + b[0]); z += (a[0] - b[0]) * (a[1] + b[1]) }
        val l = sqrt(x * x + y * y + z * z).coerceAtLeast(1e-6f); return floatArrayOf(x / l, y / l, z / l)
    }

    /** Normali verilen dışa doğru yöne çevirir. */
    private fun poly(v: List<FloatArray>, part: Part, out: FloatArray): Poly {
        var arr = v.toTypedArray(); var n = newell(arr)
        if (n[0] * out[0] + n[1] * out[1] + n[2] * out[2] < 0) { arr = arr.reversedArray(); n = floatArrayOf(-n[0], -n[1], -n[2]) }
        return Poly(arr, part, n)
    }

    private fun disc(cx: Float, cz: Float, r: Float, y: Float, seg: Int = 16) = (0 until seg).map { i -> val a = 2 * PI * i / seg; floatArrayOf(cx + (cos(a) * r).toFloat(), y, cz + (sin(a) * r).toFloat()) }

    private fun cylinder(list: MutableList<Poly>, cx: Float, cz: Float, r: Float, y0: Float, y1: Float, side: Part, top: Part, seg: Int = 16) {
        for (i in 0 until seg) {
            val a0 = 2 * PI * i / seg; val a1 = 2 * PI * (i + 1) / seg
            val p = { a: Double, y: Float -> floatArrayOf(cx + (cos(a) * r).toFloat(), y, cz + (sin(a) * r).toFloat()) }
            val mid = (a0 + a1) / 2
            list += poly(listOf(p(a0, y0), p(a1, y0), p(a1, y1), p(a0, y1)), side, floatArrayOf(cos(mid).toFloat(), 0f, sin(mid).toFloat()))
        }
        list += poly(disc(cx, cz, r, y1, seg), top, floatArrayOf(0f, 1f, 0f))
    }

    private fun box(list: MutableList<Poly>, x0: Float, x1: Float, y0: Float, y1: Float, z0: Float, z1: Float, part: Part, sides: Part = part) {
        fun q(a: FloatArray, b: FloatArray, c: FloatArray, d: FloatArray, o: FloatArray, p: Part) { list += poly(listOf(a, b, c, d), p, o) }
        val v = arrayOf(floatArrayOf(x0, y0, z0), floatArrayOf(x1, y0, z0), floatArrayOf(x1, y1, z0), floatArrayOf(x0, y1, z0),
            floatArrayOf(x0, y0, z1), floatArrayOf(x1, y0, z1), floatArrayOf(x1, y1, z1), floatArrayOf(x0, y1, z1))
        q(v[3], v[2], v[6], v[7], floatArrayOf(0f, 1f, 0f), part)
        q(v[0], v[1], v[5], v[4], floatArrayOf(0f, -1f, 0f), sides)
        q(v[4], v[5], v[6], v[7], floatArrayOf(0f, 0f, 1f), sides)
        q(v[0], v[1], v[2], v[3], floatArrayOf(0f, 0f, -1f), sides)
        q(v[0], v[4], v[7], v[3], floatArrayOf(-1f, 0f, 0f), sides)
        q(v[1], v[5], v[6], v[2], floatArrayOf(1f, 0f, 0f), sides)
    }

    private fun build(): List<Poly> {
        val list = ArrayList<Poly>()
        val o = outline()
        val h = 0.2f
        // Gövde: üst, alt ve yan yüzler (tutamaklar dahil)
        list += poly(o.map { floatArrayOf(it[0], h, it[1]) }, Part.SHELL, floatArrayOf(0f, 1f, 0f))
        list += poly(o.map { floatArrayOf(it[0], -h, it[1]) }, Part.SHELL_SIDE, floatArrayOf(0f, -1f, 0f))
        for (i in o.indices) {
            val a = o[i]; val b = o[(i + 1) % o.size]
            val mx = (a[0] + b[0]) / 2; val mz = (a[1] + b[1]) / 2
            val ex = b[0] - a[0]; val ez = b[1] - a[1]
            // Dış normal: kenara dik, merkezden uzağa
            var nx = ez; var nz = -ex; if (nx * mx + nz * (mz - 0.2f) < 0) { nx = -nx; nz = -nz }
            list += poly(listOf(floatArrayOf(a[0], -h, a[1]), floatArrayOf(b[0], -h, b[1]), floatArrayOf(b[0], h, b[1]), floatArrayOf(a[0], h, a[1])), Part.SHELL_SIDE, floatArrayOf(nx, 0f, nz))
        }
        val top = h + 0.005f
        // Siyah orta panel
        list += poly(listOf(floatArrayOf(-0.62f, top, -0.86f), floatArrayOf(0.62f, top, -0.86f), floatArrayOf(0.7f, top, 0.1f), floatArrayOf(0.52f, top, 0.5f),
            floatArrayOf(-0.52f, top, 0.5f), floatArrayOf(-0.7f, top, 0.1f)), Part.PLATE, floatArrayOf(0f, 1f, 0f))
        // Dokunmatik yüzey (kabarık) ve iki yanında ışık çubuğu
        box(list, -0.5f, 0.5f, top, top + 0.05f, -0.82f, -0.18f, Part.TOUCH, Part.DARK)
        box(list, -0.6f, -0.53f, top, top + 0.03f, -0.8f, -0.2f, Part.LIGHT)
        box(list, 0.53f, 0.6f, top, top + 0.03f, -0.8f, -0.2f, Part.LIGHT)
        // Analog çubuklar
        cylinder(list, -0.42f, 0.22f, 0.2f, top, top + 0.06f, Part.DARK, Part.DARK)
        cylinder(list, -0.42f, 0.22f, 0.15f, top + 0.06f, top + 0.2f, Part.STICK, Part.STICK_TOP)
        cylinder(list, 0.42f, 0.22f, 0.2f, top, top + 0.06f, Part.DARK, Part.DARK)
        cylinder(list, 0.42f, 0.22f, 0.15f, top + 0.06f, top + 0.2f, Part.STICK, Part.STICK_TOP)
        // Yüz tuşları (renkli işaretler)
        val bx = 1.08f; val bz = -0.28f; val d = 0.23f
        cylinder(list, bx, bz - d, 0.1f, h, h + 0.05f, Part.DARK, Part.SYMBOL_G, 12)
        cylinder(list, bx + d, bz, 0.1f, h, h + 0.05f, Part.DARK, Part.SYMBOL_R, 12)
        cylinder(list, bx, bz + d, 0.1f, h, h + 0.05f, Part.DARK, Part.SYMBOL_B, 12)
        cylinder(list, bx - d, bz, 0.1f, h, h + 0.05f, Part.DARK, Part.SYMBOL_P, 12)
        // Yön tuşları (artı)
        val dx = -1.08f; val dz = -0.28f
        box(list, dx - 0.07f, dx + 0.07f, h, h + 0.05f, dz - 0.3f, dz + 0.3f, Part.BUTTON, Part.DARK)
        box(list, dx - 0.3f, dx + 0.3f, h, h + 0.05f, dz - 0.07f, dz + 0.07f, Part.BUTTON, Part.DARK)
        // PS tuşu, Create / Options
        cylinder(list, 0f, 0.36f, 0.08f, top, top + 0.04f, Part.DARK, Part.BUTTON, 12)
        box(list, -0.66f, -0.6f, h, h + 0.04f, -0.78f, -0.62f, Part.BUTTON, Part.DARK)
        box(list, 0.6f, 0.66f, h, h + 0.04f, -0.78f, -0.62f, Part.BUTTON, Part.DARK)
        // L1 / R1 ve L2 / R2 (arka kenar)
        box(list, -1.4f, -0.8f, 0.0f, 0.14f, -0.98f, -0.8f, Part.SHELL_SIDE)
        box(list, 0.8f, 1.4f, 0.0f, 0.14f, -0.98f, -0.8f, Part.SHELL_SIDE)
        box(list, -1.35f, -0.85f, -0.22f, -0.02f, -0.94f, -0.72f, Part.DARK)
        box(list, 0.85f, 1.35f, -0.22f, -0.02f, -0.94f, -0.72f, Part.DARK)
        return list
    }
}

/**
 * Kolun yönünü gösteren 3B DualSense. [light] ışık çubuğunun gerçek rengi.
 * Boyama: düz gölgeleme (ışık sağ üst önden), arkaya bakan yüzler atlanır, uzaktan yakına sıralanır.
 */
@Composable
fun Gamepad3D(q: Orientation, tick: Int, light: Color, mono: Boolean, modifier: Modifier) {
    val polys = PadModel.polys
    val buf = remember { Array(polys.size) { FloatArray(0) } }
    Canvas(modifier) {
        tick
        val m = q.matrix()
        val ct = 0.866f; val st = 0.5f // kamera 30° yukarıdan
        val scale = size.minDimension / 3.7f; val cx = size.width / 2; val cy = size.height / 2
        val lx = 0.35f; val ly = 0.8f; val lz = 0.48f
        fun rot(p: FloatArray): FloatArray {
            val wx = m[0] * p[0] + m[1] * p[1] + m[2] * p[2]; val wy = m[3] * p[0] + m[4] * p[1] + m[5] * p[2]; val wz = m[6] * p[0] + m[7] * p[1] + m[8] * p[2]
            return floatArrayOf(wx, wy * ct - wz * st, wy * st + wz * ct)
        }
        data class Item(val i: Int, val depth: Float, val shade: Float)
        val items = ArrayList<Item>(polys.size)
        val topVisible = rot(floatArrayOf(0f, 1f, 0f))[2] > 0.02f
        polys.forEachIndexed { i, p ->
            if (p.onTop && !topVisible) return@forEachIndexed
            val n = rot(p.n)
            if (n[2] <= 0.02f) return@forEachIndexed
            val pts = FloatArray(p.v.size * 3)
            var depth = 0f
            p.v.forEachIndexed { k, v -> val r = rot(v); pts[k * 3] = r[0]; pts[k * 3 + 1] = r[1]; pts[k * 3 + 2] = r[2]; depth += r[2] }
            buf[i] = pts
            // Gövdenin büyük üst/alt yüzü önce, orta panel ondan sonra çizilir; üstteki parçalar onları örtsün.
            val bias = when { p.part == Part.SHELL || (p.part == Part.SHELL_SIDE && abs(p.n[1]) > 0.9f) -> -100f; p.part == Part.PLATE -> -50f; else -> 0f }
            items += Item(i, depth / p.v.size + bias, (0.38f + 0.62f * max(0f, n[0] * lx + n[1] * ly + n[2] * lz)).coerceIn(0f, 1f))
        }
        items.sortBy { it.depth }
        val white = if (mono) Color(0xFFE6E6E6) else Color(0xFFF3F3F5)
        val black = Color(0xFF16171B)
        items.forEach { it ->
            val p = polys[it.i]
            val base = when (p.part) {
                Part.SHELL, Part.SHELL_SIDE -> white; Part.PLATE -> Color(0xFF202126); Part.TOUCH -> Color(0xFF2A2B31)
                Part.STICK -> Color(0xFF1C1D22); Part.STICK_TOP -> Color(0xFF2E3036); Part.BUTTON -> Color(0xFF34363C); Part.DARK -> black
                Part.SYMBOL_G -> if (mono) Color(0xFF5A5A5A) else Color(0xFF3FB68B); Part.SYMBOL_R -> if (mono) Color(0xFF5A5A5A) else Color(0xFFE5506A)
                Part.SYMBOL_B -> if (mono) Color(0xFF5A5A5A) else Color(0xFF5B8DEF); Part.SYMBOL_P -> if (mono) Color(0xFF5A5A5A) else Color(0xFFD27BD9)
                Part.LIGHT -> light
            }
            val k = if (p.part == Part.LIGHT) 1f else it.shade
            val c = Color(base.red * k, base.green * k, base.blue * k, 1f)
            val pts = buf[it.i]
            val path = Path()
            for (j in 0 until pts.size / 3) {
                val z = pts[j * 3 + 2]; val f = 6f / (6f - z)
                val x = cx + pts[j * 3] * scale * f; val y = cy - pts[j * 3 + 1] * scale * f
                if (j == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            drawPath(path, c, style = Fill)
            if (p.part == Part.SHELL_SIDE || p.part == Part.SHELL) drawPath(path, c, style = Stroke(1f)) // ince dikiş boşluklarını kapatır
        }
    }
}
