@file:OptIn(ExperimentalLayoutApi::class)
package com.example.dstester

import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.sqrt

/** Temalar: varsayılan kırmızı, Ayarlar'dan siyah-beyaz. */
data class Palette(
    val bg: Color, val card: Color, val edge: Color, val chip: Color, val muted: Color, val soft: Color,
    val track: Color, val deep: Color, val btn: Color, val btnEdge: Color,
    val ok: Color, val rose: Color, val blue: Color, val violet: Color, val cube: List<Color>,
)

object Themes {
    val RED = Palette(
        bg = Color(0xFFD50000), card = Color(0xFFB71C1C), edge = Color(0xFFFF5252), chip = Color(0xFF9F1111), muted = Color(0xFFFFCDD2), soft = Color(0xFFFFEBEE),
        track = Color(0xFF7F0000), deep = Color(0xFF8E0000), btn = Color(0xFF8E0000), btnEdge = Color(0xFFFF8A80),
        ok = Color(0xFFB9F6CA), rose = Color(0xFFFFFFFF), blue = Color(0xFF82B1FF), violet = Color(0xFFEA80FC),
        cube = listOf(Color(0xFFFF1744), Color(0xFF7F0000), Color(0xFFFF8A80), Color(0xFF4A0000), Color(0xFFC62828), Color(0xFFFFFFFF)),
    )
    val MONO = Palette(
        bg = Color(0xFF000000), card = Color(0xFF0E0E0E), edge = Color(0xFF2A2A2A), chip = Color(0xFF1A1A1A), muted = Color(0xFF9A9A9A), soft = Color(0xFFDDDDDD),
        track = Color(0xFF2A2A2A), deep = Color(0xFF050505), btn = Color(0xFF141414), btnEdge = Color(0xFF5A5A5A),
        ok = Color.White, rose = Color.White, blue = Color.White, violet = Color.White,
        cube = listOf(Color(0xFFE0E0E0), Color(0xFF3A3A3A), Color(0xFFFFFFFF), Color(0xFF1A1A1A), Color(0xFF9E9E9E), Color(0xFF000000)),
    )
    var mono by mutableStateOf(false); private set
    private var prefs: android.content.SharedPreferences? = null
    fun init(c: Context) { prefs = c.getSharedPreferences("tema", Context.MODE_PRIVATE); mono = prefs!!.getBoolean("mono", false) }
    fun set(v: Boolean) { mono = v; prefs?.edit()?.putBoolean("mono", v)?.apply() }
    val p: Palette get() = if (mono) MONO else RED
}

private val BG get() = Themes.p.bg
private val CardC get() = Themes.p.card
private val Edge get() = Themes.p.edge
private val ChipC get() = Themes.p.chip
private val Muted get() = Themes.p.muted
private val Ok get() = Themes.p.ok
private val Rose get() = Themes.p.rose
private val BlueC get() = Themes.p.blue
private val Violet get() = Themes.p.violet
private val Track get() = Themes.p.track
private val Deep get() = Themes.p.deep
private val Soft get() = Themes.p.soft

class MainActivity : ComponentActivity() {
    private val ACTION = "com.example.dstester.USB_PERMISSION"
    private var ds by mutableStateOf<DualSense?>(null)
    private var status by mutableStateOf("Kablo bekleniyor")
    private var crash by mutableStateOf<String?>(null)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == UsbManager.ACTION_USB_DEVICE_DETACHED) {
                ds?.close(); ds = null; status = "Kontrolcü çıkarıldı"
            } else connect()
        }
    }

    private fun connect() {
        val um = getSystemService(USB_SERVICE) as UsbManager
        val d = um.deviceList.values.firstOrNull {
            it.vendorId == 0x054C && (it.productId == 0x0CE6 || it.productId == 0x0DF2)
        } ?: return
        if (!um.hasPermission(d)) {
            val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION).setPackage(packageName), PendingIntent.FLAG_MUTABLE)
            um.requestPermission(d, pi); return
        }
        ds?.close()
        ds = DualSense.open(um, d)
        status = if (ds != null) "${d.productName ?: "DualSense"} · USB-C" else "USB arayüzü açılamadı"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Themes.init(this)
        CrashLog.install(this)
        crash = CrashLog.take(this)
        val f = IntentFilter(ACTION).apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED); addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        connect()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = BG, primary = Color.White, onPrimary = Color.Black, surfaceVariant = CardC)) {
                Surface(color = BG) { App(ds, status) }
                crash?.let { log ->
                    AlertDialog(onDismissRequest = { crash = null }, containerColor = CardC,
                        title = { Text("Uygulama son kullanımda kapandı", color = Color.White) },
                        text = { Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) { Text(log, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 10.sp) } },
                        confirmButton = { TextButton({
                            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Çökme", log)); crash = null
                        }) { Text("Kopyala", color = Color.White) } },
                        dismissButton = { TextButton({ crash = null }) { Text("Kapat", color = Muted) } })
                }
            }
        }
    }

    override fun onDestroy() { unregisterReceiver(receiver); ds?.close(); super.onDestroy() }
}

// ---------- Ortak bileşenler ----------
@Composable
fun T(text: String, size: Int = 14, color: Color = Color.White, bold: Boolean = false,
      mono: Boolean = false, spacing: Float = 0f, modifier: Modifier = Modifier) {
    Text(text, modifier, color = color, fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default, letterSpacing = spacing.sp)
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(16.dp)
    Column(modifier.fillMaxWidth().clip(sh).background(CardC).border(1.dp, Edge, sh).padding(16.dp), content = content)
}

@Composable
fun Section(title: String, sub: String) {
    Column(Modifier.padding(top = 20.dp, bottom = 10.dp)) { T(title, 20, bold = true); T(sub, 12, Muted) }
}

@Composable
fun Stat(label: String, value: String, unit: String, modifier: Modifier) {
    Panel(modifier) {
        T(label.uppercase(), 11, Muted, spacing = 1f); Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            T(value, 30, bold = true)
            if (unit.isNotEmpty()) T(unit, 13, Muted, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
        }
    }
}

@Composable
fun SmallBtn(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val sh = RoundedCornerShape(20.dp)
    Box(modifier.clip(sh).background(Themes.p.btn).border(1.dp, Themes.p.btnEdge, sh)
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {
        T(text.uppercase(), 11, bold = true, spacing = 1f)
    }
}

@Composable
fun Pill(text: String, color: Color = Color.White) {
    val sh = RoundedCornerShape(20.dp)
    Box(Modifier.clip(sh).border(1.dp, color, sh).padding(horizontal = 12.dp, vertical = 6.dp)) {
        T(text, 11, color, bold = true, spacing = 1f)
    }
}

@Composable
fun WSlider(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        T(label.uppercase(), 11, Muted, spacing = 1f); T("$value", 13, bold = true)
    }
    Slider(value.toFloat(), { onChange(it.toInt()) }, valueRange = range.first.toFloat()..range.last.toFloat(),
        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White,
            inactiveTrackColor = Track))
}

@Composable
fun Key(text: String, on: Boolean, c: Color = Color.White, w: Int = 52) {
    val sh = RoundedCornerShape(12.dp)
    val plain = c == Color.White
    val fg = if (on) Color.Black else if (plain) Color.White else c
    Box(Modifier.size(w.dp, 46.dp).clip(sh).background(if (on) c else ChipC)
        .border(1.dp, if (on) c else if (plain) Edge else c.copy(alpha = 0.6f), sh), contentAlignment = Alignment.Center) {
        val icon: ImageVector? = when (text) { "▲" -> Icons.Rounded.KeyboardArrowUp; "▼" -> Icons.Rounded.KeyboardArrowDown
            "◀" -> Icons.AutoMirrored.Rounded.KeyboardArrowLeft; "▶" -> Icons.AutoMirrored.Rounded.KeyboardArrowRight; else -> null }
        when {
            icon != null -> Icon(icon, text, tint = fg, modifier = Modifier.size(28.dp))
            text in listOf("△", "○", "✕", "□") -> Canvas(Modifier.size(20.dp)) {
                val st = Stroke(2.5.dp.toPx()); val w0 = size.width; val h0 = size.height
                when (text) {
                    "△" -> drawPath(androidx.compose.ui.graphics.Path().apply { moveTo(w0 / 2, 1f); lineTo(w0 - 1f, h0 - 2f); lineTo(1f, h0 - 2f); close() }, fg, style = st)
                    "○" -> drawCircle(fg, w0 / 2 - 2f, style = st)
                    "✕" -> { drawLine(fg, Offset(2f, 2f), Offset(w0 - 2f, h0 - 2f), st.width); drawLine(fg, Offset(w0 - 2f, 2f), Offset(2f, h0 - 2f), st.width) }
                    else -> drawRect(fg, Offset(2f, 2f), androidx.compose.ui.geometry.Size(w0 - 4f, h0 - 4f), style = st)
                }
            }
            else -> T(text, 14, fg, true)
        }
    }
}

@Composable
fun Cap(text: String) { Spacer(Modifier.height(14.dp)); T(text, 10, Muted, bold = true, spacing = 1.5f); Spacer(Modifier.height(8.dp)) }

@Composable
fun Title(title: String, sub: String) {
    Column(Modifier.padding(top = 8.dp)) { T(title, 24, bold = true, spacing = 1.5f); T(sub, 12, Muted) }
}

fun pulse(ds: DualSense?, o: Output, left: Boolean, both: Boolean = false) {
    Thread {
        if (left || both) o.strong = 255
        if (!left || both) o.weak = 255
        ds?.send(o); Thread.sleep(600)
        o.strong = 0; o.weak = 0
        ds?.send(o)
    }.start()
}

// ---------- Ana ekran ----------
@Composable
fun App(ds: DualSense?, status: String) {
    var state by remember { mutableStateOf(InputState()) }
    val out = remember { Output() }
    var tab by remember { mutableIntStateOf(0) }
    var hz by remember { mutableIntStateOf(0) }
    var yaw by remember { mutableFloatStateOf(0f) }
    val bias = remember { FloatArray(3) }
    val q = remember { Orientation() }
    var testRun by remember { mutableIntStateOf(0) }
    var report by remember { mutableStateOf(false) }
    var jack by remember { mutableStateOf(false) }
    val trail = remember { mutableStateListOf<Offset>() }
    fun push() { ds?.let { d -> Thread { d.send(out) }.start() } }

    LaunchedEffect(ds) {
        ds?.let { d ->
            var lastT = 0L
            val main = android.os.Handler(android.os.Looper.getMainLooper())
            val latest = java.util.concurrent.atomic.AtomicReference<InputState?>(null)
            val pending = java.util.concurrent.atomic.AtomicBoolean(false)
            val newPts = java.util.concurrent.ConcurrentLinkedQueue<Offset>()
            withContext(Dispatchers.IO) {
                d.readLoop({ isActive }) { s ->
                    try {
                        val now = System.nanoTime()
                        if (lastT != 0L) {
                            val dt = ((now - lastT) / 1e9f).coerceIn(0f, 0.05f)
                            q.update(s.gyro.mapIndexed { i, g -> (g - bias[i]) / GYRO_PER_DPS }.toFloatArray(), s.accel.map { it.toFloat() }.toFloatArray(), dt)
                        }
                        lastT = now
                        s.touch.forEach { (x, y) -> newPts.add(Offset((x / 1920f).coerceIn(0f, 1f), (y / 1080f).coerceIn(0f, 1f))) }
                        latest.set(s)
                        // Ekrandaki bütün durumlar yalnızca ana iş parçacığında, karede en fazla bir kez güncellenir
                        // (dokunmatikte parmak sürünce gelen yoğun paketler çakışıp çökmeye yol açıyordu).
                        if (pending.compareAndSet(false, true)) main.post {
                            pending.set(false)
                            latest.get()?.let { state = it }
                            yaw = q.euler()[2]
                            while (true) { val p = newPts.poll() ?: break; trail.add(p) }
                            while (trail.size > 150) trail.removeAt(0)
                        }
                    } catch (e: Exception) { android.util.Log.w("DSTester", "paket", e) }
                }
            }
        }
    }
    LaunchedEffect(ds) {
        var last = 0
        while (true) { delay(1000); val p = state.packets; hz = if (p >= last) p - last else 0; last = p }
    }
    LaunchedEffect(ds) { push() }
    // Geri tepme: R2 sonuna yakın basılınca kolun motorları kısa ve sert vurur; otomatik silahta basılı tuttukça tekrarlar.
    LaunchedEffect(ds) {
        val d = ds ?: return@LaunchedEffect
        var held = false; var nextShot = 0L
        withContext(Dispatchers.IO) {
            while (isActive) {
                val pressed = state.r2 > 170
                val now = System.currentTimeMillis()
                val fire = out.recoil > 0 && pressed && (!held || (out.autoMs > 0 && now >= nextShot))
                if (fire) {
                    nextShot = now + out.autoMs
                    out.strong = out.recoil; out.weak = (out.recoil * 0.6f).toInt(); d.send(out)
                    delay(if (out.autoMs in 1..80) 35 else 60)
                    out.strong = 0; out.weak = 0; d.send(out)
                }
                held = pressed
                delay(8)
            }
        }
    }

    Scaffold(containerColor = BG, bottomBar = {
        NavigationBar(containerColor = BG) {
            listOf(Icons.Rounded.Dashboard to "Panel", Icons.Rounded.SportsEsports to "Giriş", Icons.Rounded.Vibration to "Geri Bildirim",
                Icons.Rounded.Sensors to "Sensörler", Icons.Rounded.Settings to "Ayarlar").forEachIndexed { i, (ic, t) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Icon(ic, t) }, label = { Text(t, fontSize = 10.sp, maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(selectedTextColor = Color.White, unselectedTextColor = Muted, selectedIconColor = if (Themes.mono) Color.Black else Color.White, unselectedIconColor = Muted,
                        indicatorColor = Track))
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            when (tab) {
                0 -> DashTab(ds, state, out, hz, status, testRun, { testRun++; pulse(ds, out, true, true) }, { report = true })
                1 -> InputTab(state, trail)
                2 -> FeedbackTab(ds, out, ::push)
                4 -> SettingsTab()
                else -> SensorTab(ds, state, out, q, ::push) { q.reset(); state.gyro.forEachIndexed { i, g -> bias[i] = g.toFloat() } }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (report) AlertDialog(onDismissRequest = { report = false }, confirmButton = {
        TextButton({ report = false }) { Text("Kapat") }
    }, title = { Text("Test Raporu") }, text = {
        val s = state
        Text("Bağlantı: $status\nPil: %${s.battery} (${s.charging})\nPolling: $hz Hz\nPaket: ${s.packets}\n" +
            "Jiroskop: ${s.gyro.joinToString(", ")}\nİvme: ${s.accel.joinToString(", ")}\n" +
            "Basılı tuşlar: ${s.buttons.joinToString(" ").ifEmpty { "—" }}\nDokunmatik: ${s.touch.size}/2 parmak",
            fontFamily = FontFamily.Monospace, fontSize = 12.sp)
    })
}

// ---------- Panel ----------
@Composable
fun DashTab(ds: DualSense?, s: InputState, o: Output, hz: Int, status: String, run: Int, rerun: () -> Unit, report: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Gamepad, null, tint = Color.White, modifier = Modifier.size(24.dp)); Spacer(Modifier.width(8.dp))
        T("DUALSENSE", 18, bold = true, spacing = 1.5f, modifier = Modifier.weight(1f))
        Pill("PİL %${s.battery}"); Spacer(Modifier.width(8.dp)); Pill(if (ds != null) "USB BAĞLI" else "YOK")
    }
    Spacer(Modifier.height(16.dp))
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color.White).clickable(onClick = report)
        .padding(vertical = 16.dp), contentAlignment = Alignment.Center) { T("RAPOR OLUŞTUR", 14, Color.Black, true, spacing = 1f) }
    Section("Performans", "Canlı telemetri")
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("Gecikme", if (hz > 0) "${1000 / hz}" else "—", "ms", Modifier.weight(1f))
        Stat("Polling", "$hz", "Hz", Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("Pil", "${s.battery}", "%", Modifier.weight(1f))
        Stat("Güç", if (s.charging == "Pilde") "PİL" else "USB", "", Modifier.weight(1f))
    }
    Section("Bağlantı", "")
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Usb, null, tint = Color.White, modifier = Modifier.size(26.dp)); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { T("USB-C (OTG)", 16, bold = true); T(status, 12, Muted) }
            Pill(if (ds != null) "AKTİF" else "YOK")
        }
    }
    Section("Sistem", "Donanım kancaları")
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.FactCheck, null, tint = Color.White, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
            T("KENDİ KENDİNİ TEST", 13, bold = true, spacing = 1f, modifier = Modifier.weight(1f))
            SmallBtn("Tekrar", onClick = rerun)
        }
        val anyG = s.gyro.any { it != 0 }; val anyA = s.accel.any { it != 0 }
        listOf("Jiroskop" to anyG, "İvmeölçer" to anyA, "Pil API" to (s.battery > 0),
            "Haptik Motor" to (ds != null)).forEach { (n, pass) ->
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                T(n, 14, Soft, modifier = Modifier.weight(1f))
                Icon(if (pass) Icons.Rounded.CheckCircle else Icons.Rounded.HourglassTop, null, tint = if (pass) Color.White else Muted, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp))
                T(if (pass) "GEÇTİ" else "BEKLİYOR", 12, if (pass) Color.White else Muted, true)
            }
        }
    }
}

// ---------- Giriş ----------
@Composable
fun InputTab(s: InputState, trail: SnapshotStateList<Offset>) {
    Title("GİRİŞ MATRİSİ", "Canlı · Tuşlar · Çubuklar · Dokunmatik")
    Section("Tuşlar ve Giriş Matrisi", "")
    val b = s.buttons
    fun has(vararg k: String) = k.any { it in b }
    Panel {
        T("YÖN TUŞLARI", 10, Muted, true, spacing = 1.5f); Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Key("▲", has("↑", "↗", "↖"))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Key("◀", has("←", "↙", "↖")); Spacer(Modifier.width(52.dp)); Key("▶", has("→", "↗", "↘"))
            }
            Key("▼", has("↓", "↘", "↙"))
        }
        Cap("YÜZ TUŞLARI")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Key("△", "△" in b, Ok); Key("○", "○" in b, Rose); Key("✕", "✕" in b, BlueC); Key("□", "□" in b, Violet)
        }
        Cap("OMUZ / TETİK")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Key("L1", "L1" in b); Key("R1", "R1" in b); Key("L2", "L2" in b); Key("R2", "R2" in b)
        }
        Cap("YARDIMCI")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Key("CRE", "Create" in b); Key("OPT", "Options" in b); Key("PS", "PS" in b); Key("MİK", "Mute" in b)
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(ChipC).padding(12.dp)) {
            T("Eş zamanlı tuş: ${b.count { it.length > 1 || it in listOf("△", "○", "✕", "□") }} aktif", 13, Soft)
        }
    }
    Section("Analog Çubuklar", "L3 / R3")
    Panel {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stick("L3", s.lx, s.ly, "L3" in b); Stick("R3", s.rx, s.ry, "R3" in b)
        }
    }
    Section("Tetikler", "Analog değer")
    Panel {
        listOf("L2" to s.l2, "R2" to s.r2).forEach { (n, v) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T(n, 12, Muted, true); T("$v", 12, bold = true, mono = true)
            }
            LinearProgressIndicator({ v / 255f }, Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                Color.White, Track); Spacer(Modifier.height(10.dp))
        }
    }
    Section("Dokunmatik Yüzey", "2 parmaklı çoklu dokunma")
    Panel {
        Box(Modifier.fillMaxWidth().aspectRatio(320f / 220f).clip(RoundedCornerShape(12.dp)).background(Deep),
            contentAlignment = Alignment.Center) {
            Canvas(Modifier.matchParentSize()) {
                val pts = trail.toList()
                pts.forEachIndexed { i, p ->
                    drawCircle(Color.White.copy(alpha = 0.15f + 0.6f * i / pts.size.coerceAtLeast(1)), 5f,
                        Offset(p.x * size.width, p.y * size.height))
                }
                s.touch.forEach { (x, y) -> drawCircle(Color.White, 16f, Offset(x / 1920f * size.width, y / 1080f * size.height)) }
            }
            if (trail.isEmpty()) T("1-2 PARMAKLA SÜRÜKLE", 12, Muted, true, spacing = 1f)
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Parmak: ${s.touch.size}/2 · Boyut: 1920×1080", 12, Muted, modifier = Modifier.weight(1f))
            SmallBtn("Temizle") { trail.clear() }
        }
    }
}

@Composable
fun Stick(label: String, x: Int, y: Int, pressed: Boolean) {
    val nx = (x - 128) / 127f; val ny = (y - 128) / 127f
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(120.dp)) {
            val r = size.minDimension / 2
            drawCircle(Track, r, style = Stroke(3f))
            drawLine(Track, Offset(0f, r), Offset(size.width, r), 2f)
            drawLine(Track, Offset(r, 0f), Offset(r, size.height), 2f)
            drawCircle(if (pressed) Ok else Color.White, 14f, Offset(r + nx * (r - 14f), r + ny * (r - 14f)))
        }
        T(label, 16, bold = true)
        T("X %.2f  Y %.2f".format(nx, ny), 11, Muted, mono = true)
        T(if (abs(nx) < 0.1f && abs(ny) < 0.1f) "ORTADA" else "AKTİF", 11, bold = true, spacing = 1f)
    }
}

// ---------- Geri bildirim ----------
@Composable
fun FeedbackTab(ds: DualSense?, o: Output, push: () -> Unit) {
    Title("GERİ BİLDİRİM", "Tetikler · Haptik · Aydınlatma")
    Section("Adaptif Tetikler", "L2 / R2")
    Panel {
        TriggerPanel("L2 tetik modu", o.left, o.leftPreset, left = true,
            pick = { p -> o.left = p.forTrigger(true); o.leftPreset = p.name; push() }) { o.left = it; o.leftPreset = null; push() }
        Spacer(Modifier.height(20.dp))
        TriggerPanel("R2 tetik modu", o.right, o.rightPreset, left = false,
            pick = { p -> o.right = p.forTrigger(false); o.rightPreset = p.name; o.recoil = p.recoil; o.autoMs = p.autoMs; push() }) { o.right = it; o.rightPreset = null; push() }
        Cap("R2 GERİ TEPME")
        WSlider("Güç (0 = kapalı)", o.recoil, 0..255) { o.recoil = it }
        WSlider("Otomatik atış aralığı ms (0 = tek atış)", o.autoMs, 0..300) { o.autoMs = it }
    }
    Section("Haptik Geri Bildirim", "Çift voice-coil eyleyici")
    Panel {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f)) { T("SOL MOTOR", 10, Muted, true, spacing = 1.5f); Segments(o.strong) }
            Column(Modifier.weight(1f)) { T("SAĞ MOTOR", 10, Muted, true, spacing = 1.5f); Segments(o.weak) }
        }
        Spacer(Modifier.height(8.dp))
        WSlider("Sol motor (güçlü)", o.strong, 0..255) { o.strong = it; push() }
        WSlider("Sağ motor (hafif)", o.weak, 0..255) { o.weak = it; push() }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallBtn("Sol test", Modifier.weight(1f)) { pulse(ds, o, true) }
            SmallBtn("Sağ test", Modifier.weight(1f)) { pulse(ds, o, false) }
        }
        Spacer(Modifier.height(8.dp))
        SmallBtn("Eski titreşim testi", Modifier.fillMaxWidth()) { pulse(ds, o, true, true) }
        Spacer(Modifier.height(8.dp))
        SmallBtn("Durdur", Modifier.fillMaxWidth()) { o.strong = 0; o.weak = 0; push() }
    }
    Section("RGB Lightbar", "Çift lightbar renk kontrolü")
    Panel {
        Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(14.dp)).background(Color(o.r, o.g, o.b)),
            contentAlignment = Alignment.Center) {
            val dark = (o.r * 0.3 + o.g * 0.6 + o.b * 0.1) > 150
            T("RGB(${o.r}, ${o.g}, ${o.b})", 16, if (dark) Color.Black else Color.White, true, mono = true)
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("Mavi" to Triple(0, 0, 255), "Kırmızı" to Triple(255, 0, 0), "Yeşil" to Triple(0, 255, 0), "Sarı" to Triple(255, 200, 0),
                "Mor" to Triple(140, 0, 255), "Pembe" to Triple(255, 40, 150), "Beyaz" to Triple(255, 255, 255)).forEach { (name, c) ->
                val (r, g, b) = c
                val on = o.r == r && o.g == g && o.b == b
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { o.r = r; o.g = g; o.b = b; push() }.padding(2.dp)) {
                    Box(Modifier.size(36.dp).clip(CircleShape).background(Color(r, g, b)).border(if (on) 3.dp else 1.dp, if (on) Color.White else Edge, CircleShape))
                    T(name, 10, if (on) Color.White else Muted, on, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        WSlider("Kırmızı", o.r, 0..255) { o.r = it; push() }
        WSlider("Yeşil", o.g, 0..255) { o.g = it; push() }
        WSlider("Mavi", o.b, 0..255) { o.b = it; push() }
    }
    Section("Oyuncu Işığı", "1 - 4. oyuncu")
    Panel {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
            (0..4).forEach { i ->
                val lit = (o.player shr i) and 1 == 1
                Box(Modifier.padding(horizontal = 6.dp).size(width = 26.dp, height = 8.dp).clip(RoundedCornerShape(4.dp)).background(if (lit) Color.White else Track))
            }
        }
        Spacer(Modifier.height(10.dp))
        PLAYERS.forEach { (name, mask) ->
            val on = o.player == mask
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (on) Color.White else Color.Transparent)
                .clickable { o.player = mask; push() }.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                T(name, 14, if (on) Color.Black else Color.White, true, modifier = Modifier.weight(1f))
                if (on) Icon(Icons.Rounded.CheckCircle, null, tint = Color.Black, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Mikrofon LED", 14, modifier = Modifier.weight(1f)); Switch(o.muteLed, { o.muteLed = it; push() })
        }
    }
}

@Composable
fun Segments(level: Int) {
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth().height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(16) { i ->
            Box(Modifier.weight(1f).fillMaxHeight().background(if (level * 16 / 256 > i) Color.White else Track))
        }
    }
}

@Composable
fun TriggerPanel(title: String, c: TriggerCfg, preset: String?, left: Boolean, pick: (Preset) -> Unit, onChange: (TriggerCfg) -> Unit) {
    T(title.uppercase(), 10, Muted, true, spacing = 1.5f); Spacer(Modifier.height(8.dp))
    var menu by remember { mutableStateOf(false) }
    // Tek kutu: dokununca kaydırılabilir hazır ayar menüsü açılır.
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ChipC).border(1.dp, Edge, RoundedCornerShape(14.dp))
        .clickable { menu = true }.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Tune, null, tint = Color.White, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            T("HAZIR AYAR", 10, Muted, true, spacing = 1.5f)
            T(preset ?: "Seç", 15, bold = true)
        }
        Icon(Icons.Rounded.UnfoldMore, null, tint = Muted)
    }
    if (menu) PresetMenu(title, preset, left, { menu = false }) { pick(it); menu = false }
    Cap("MOD")
    val names = mapOf(TMode.OFF to "Kapalı", TMode.RIGID to "Sert", TMode.PULSE to "Darbe", TMode.FEEDBACK to "Geri Besleme",
        TMode.WEAPON to "Silah", TMode.BOW to "Yay", TMode.GALLOP to "Dörtnala", TMode.MACHINE to "Makine", TMode.VIBRATION to "Titreşim")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TMode.values().forEach { m ->
            val on = c.mode == m
            Box(Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Color.White else ChipC)
                .clickable { onChange(c.copy(mode = m)) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                T(names[m] ?: m.label, 13, if (on) Color.Black else Soft, true)
            }
        }
    }
    Cap("ÖZEL PARAMETRELER")
    WSlider("Direnç (1-8)", c.strength, 1..8) { onChange(c.copy(strength = it)) }
    WSlider("Başlangıç bölgesi", c.start, 0..9) { onChange(c.copy(start = it)) }
    WSlider("Bitiş bölgesi", c.end, 0..9) { onChange(c.copy(end = it)) }
    WSlider("Frekans", c.freq, 0..255) { onChange(c.copy(freq = it)) }
}

// ---------- Sensörler ----------
@Composable
fun SensorTab(ds: DualSense?, s: InputState, o: Output, q: Orientation, push: () -> Unit, calibrate: () -> Unit) {
    Title("SENSÖRLER", "Hareket · Ses · Güç")
    val ax = s.accel[0] / 8192f; val ay = s.accel[1] / 8192f; val az = s.accel[2] / 8192f
    val e = q.euler()
    Section("6 Eksenli Hareket", "Kolu çevir, kutu da dönsün")
    Panel {
        RealGamepad3D(q, Color(o.r, o.g, o.b), Modifier.fillMaxWidth().height(300.dp)) {
            Gamepad3D(q, s.packets, Color(o.r, o.g, o.b), Themes.mono, Modifier.fillMaxWidth().height(280.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("EĞİM" to e[0], "YUVARLANMA" to e[1], "SAPMA" to e[2]).forEach { (n, v) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    T(n, 10, Muted, true, spacing = 1.5f); T("%.1f°".format(v), 20, bold = true)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        SmallBtn("Kalibre et (kolu düz bırak)", Modifier.fillMaxWidth(), calibrate)
    }
    Section("Ham Telemetri", "")
    Panel {
        TelRow("JİROSKOP (°/s)", s.gyro.map { it / GYRO_PER_DPS })
        Spacer(Modifier.height(16.dp))
        TelRow("İVMEÖLÇER (g)", listOf(ax, ay, az))
    }
    AudioPanel(ds, s, o, push)
    Section("Güç", "Pil tanılama")
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("Seviye", "${s.battery}", "%", Modifier.weight(1f))
        Stat("Durum", when (s.charging) { "Şarj oluyor" -> "ŞARJ"; "Dolu" -> "DOLU"; else -> "PİL" }, "", Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Stat("Tüketim", "—", "W", Modifier.weight(1f))
        Stat("Voltaj (tahmini)", "%.2f".format(3.2f + s.battery / 100f), "V", Modifier.weight(1f))
    }
}

/** Kolun yönünü gösteren, ışıklı yüzlü 3B kutu (kolun en-boy oranında). */
@Composable
fun Cube(q: Orientation, tick: Int, modifier: Modifier) {
    Canvas(modifier) {
        tick // her yeni pakette yeniden çiz
        val m = q.matrix()
        val hx = 1.6f; val hy = 0.45f; val hz = 1.0f
        val v = listOf(
            floatArrayOf(-hx, -hy, -hz), floatArrayOf(hx, -hy, -hz), floatArrayOf(hx, hy, -hz), floatArrayOf(-hx, hy, -hz),
            floatArrayOf(-hx, -hy, hz), floatArrayOf(hx, -hy, hz), floatArrayOf(hx, hy, hz), floatArrayOf(-hx, hy, hz))
        // Kamera hafif yukarıdan bakar (35°), kolun üstü ve önü birlikte görünür.
        val ct = 0.819f; val st = 0.574f
        val rot = v.map { p ->
            val wx = m[0] * p[0] + m[1] * p[1] + m[2] * p[2]; val wy = m[3] * p[0] + m[4] * p[1] + m[5] * p[2]; val wz = m[6] * p[0] + m[7] * p[1] + m[8] * p[2]
            floatArrayOf(wx, wy * ct - wz * st, wy * st + wz * ct)
        }
        val scale = size.minDimension / 4.2f; val cx = size.width / 2; val cy = size.height / 2
        // Ekran: x sağ, y yukarı, z bize doğru; hafif perspektif.
        fun proj(p: FloatArray): Offset { val k = 5f / (5f - p[2]); return Offset(cx + p[0] * scale * k, cy - p[1] * scale * k) }
        val faces = listOf(
            intArrayOf(4, 5, 6, 7) to Themes.p.cube[0], // ön (oyuncuya bakan): touchpad tarafı
            intArrayOf(1, 0, 3, 2) to Themes.p.cube[1], // arka
            intArrayOf(3, 7, 6, 2) to Themes.p.cube[2], // üst
            intArrayOf(0, 1, 5, 4) to Themes.p.cube[3], // alt
            intArrayOf(0, 4, 7, 3) to Themes.p.cube[4], // sol
            intArrayOf(5, 1, 2, 6) to Themes.p.cube[4], // sağ
        )
        faces.map { (f, c) -> Triple(f, c, f.map { rot[it][2] }.average()) }.sortedBy { it.third }.forEach { (f, c, _) ->
            // Arka yüzleri atla (normal kameradan uzaksa).
            val a = rot[f[0]]; val b = rot[f[1]]; val d = rot[f[3]]
            val nz = (b[0] - a[0]) * (d[1] - a[1]) - (b[1] - a[1]) * (d[0] - a[0])
            if (nz <= 0f) return@forEach
            val path = androidx.compose.ui.graphics.Path().apply { f.forEachIndexed { i, idx -> val p = proj(rot[idx]); if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y) }; close() }
            drawPath(path, c.copy(alpha = 0.92f))
            drawPath(path, (if (Themes.mono) Color.Black else Color.White).copy(alpha = 0.85f), style = Stroke(2.5f))
        }
        // Ön yüzde "DS5" yönü belli olsun diye ışık çubuğu çizgisi
        val p1 = proj(rot[7]); val p2 = proj(rot[6])
        drawLine(Themes.p.cube[5], Offset(p1.x + (p2.x - p1.x) * 0.3f, p1.y + (p2.y - p1.y) * 0.3f), Offset(p1.x + (p2.x - p1.x) * 0.7f, p1.y + (p2.y - p1.y) * 0.7f), 6f)
    }
}

@Composable
fun AudioPanel(ds: DualSense?, s: InputState, o: Output, push: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    var level by remember { mutableFloatStateOf(0f) }
    var recorded by remember { mutableStateOf<ShortArray?>(null) }
    var msg by remember { mutableStateOf("") }
    var played by remember { mutableStateOf("") }
    var audioInfo by remember { mutableStateOf(DsAudio.scan(context)) }
    // Kolun USB ses aygıtı, HID bağlantısından biraz sonra Android'de belirir; aygıt eklenip çıkınca yenilenir.
    DisposableEffect(ds) {
        val manager = context.getSystemService(android.media.AudioManager::class.java)
        val cb = object : android.media.AudioDeviceCallback() {
            override fun onAudioDevicesAdded(added: Array<out android.media.AudioDeviceInfo>?) { audioInfo = DsAudio.scan(context) }
            override fun onAudioDevicesRemoved(removed: Array<out android.media.AudioDeviceInfo>?) { audioInfo = DsAudio.scan(context) }
        }
        audioInfo = DsAudio.scan(context)
        manager.registerAudioDeviceCallback(cb, android.os.Handler(android.os.Looper.getMainLooper()))
        onDispose { manager.unregisterAudioDeviceCallback(cb) }
    }
    val headphones = (s.status2 and 0x01) != 0
    val headMic = (s.status2 and 0x02) != 0
    val askMic = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) msg = "Mikrofon izni verilmedi"
    }
    fun route(path: Int) { o.audioPath = path; push() }
    fun run(label: String, block: suspend () -> Unit) {
        if (busy != null) return
        busy = label; msg = ""
        scope.launch { try { block() } finally { busy = null } }
    }
    Section("Ses G/Ç", "Hoparlör · 3.5mm jak · Mikrofon")
    Panel {
        if (ds != null && audioInfo.out == null) { T("Kolun ses aygıtı Android'de görünmüyor; kabloyu çıkarıp tak. Yine görünmezse bu telefon kolun USB sesini desteklemiyor olabilir.", 12, Rose); Spacer(Modifier.height(10.dp)) }
        T(audioInfo.text, 10, Muted, mono = true); Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.VolumeUp, null, tint = Color.White, modifier = Modifier.size(26.dp)); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { T("Dahili Hoparlör", 15, bold = true); T(if (busy == "hoparlor") "Çalıyor…" else "Kolun hoparlöründen ton", 12, Muted) }
            SmallBtn("Test") {
                run("hoparlor") {
                    route(3); kotlinx.coroutines.delay(150)
                    val ok = withContext(Dispatchers.IO) { DsAudio.tone(context, true, true, 1500, sweep = true) }
                    played = DsAudio.lastInfo
                    if (!ok) msg = "Ses çalınamadı: " + DsAudio.lastInfo
                    route(if (headphones) 0 else 3)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Headphones, null, tint = Color.White, modifier = Modifier.size(26.dp)); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                T("3.5mm Jak", 15, bold = true)
                T(when { headphones && headMic -> "Mikrofonlu kulaklık takılı"; headphones -> "Kulaklık takılı"; else -> "Takılı değil" }, 12, if (headphones) Ok else Muted)
            }
            SmallBtn("Sol") { run("sol") { route(0); kotlinx.coroutines.delay(150); val ok = withContext(Dispatchers.IO) { DsAudio.tone(context, true, false, 900, 660.0) }; played = DsAudio.lastInfo; if (!ok) msg = "Ses çalınamadı: " + DsAudio.lastInfo } }
            Spacer(Modifier.width(6.dp))
            SmallBtn("Sağ") { run("sag") { route(0); kotlinx.coroutines.delay(150); val ok = withContext(Dispatchers.IO) { DsAudio.tone(context, false, true, 900, 990.0) }; played = DsAudio.lastInfo; if (!ok) msg = "Ses çalınamadı: " + DsAudio.lastInfo } }
        }
        if (busy == "hoparlor" || busy == "sol" || busy == "sag" || busy == "dinle") {
            Spacer(Modifier.height(10.dp)); LinearProgressIndicator(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), Ok, Track)
        }
        Spacer(Modifier.height(14.dp))
        WSlider("Hoparlör sesi (kol)", o.speakerVol, 0..255) { o.speakerVol = it; push() }
        WSlider("Kulaklık sesi (kol)", o.headVol, 0..127) { o.headVol = it; push() }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Mic, null, tint = Color.White, modifier = Modifier.size(26.dp)); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                T("Mikrofon", 15, bold = true)
                T(when (busy) { "kayit" -> "Konuş… kaydediliyor"; "dinle" -> "Kayıt çalınıyor"; else -> if (recorded != null) "Kayıt hazır, dinleyebilirsin" else if (headMic) "Kulaklık mikrofonu kullanılacak" else "Kolun dahili mikrofonu" }, 12, Muted)
            }
            SmallBtn("Kaydet") {
                if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) { askMic.launch(android.Manifest.permission.RECORD_AUDIO); return@SmallBtn }
                run("kayit") {
                    o.micSelect = if (headMic) 2 else 1; o.micVol = 0x40; push()
                    recorded = withContext(Dispatchers.IO) { DsAudio.record(context, 3000) { level = it } }
                    level = 0f
                    if (recorded == null) msg = "Mikrofon açılamadı" else if ((recorded?.maxOfOrNull { abs(it.toInt()) } ?: 0) < 200) msg = "Ses gelmedi; mikrofonun kapalı (Mute) olmadığına bak"
                }
            }
            if (recorded != null) { Spacer(Modifier.width(6.dp)); SmallBtn("Dinle") {
                run("dinle") {
                    route(if (headphones) 0 else 3); kotlinx.coroutines.delay(150)
                    val rec = recorded
                    if (rec != null) { withContext(Dispatchers.IO) { DsAudio.play(context, DsAudio.output(context), rec, 48000, 1) }; played = DsAudio.lastInfo }
                }
            } }
        }
        if (busy == "kayit") { Spacer(Modifier.height(10.dp)); LinearProgressIndicator({ level.coerceIn(0f, 1f) }, Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), Ok, Track) }
        if (played.isNotEmpty()) { Spacer(Modifier.height(10.dp)); T(played, 11, Muted) }
        if (msg.isNotEmpty()) { Spacer(Modifier.height(10.dp)); T(msg, 12, Rose) }
    }
}

@Composable
fun TelRow(title: String, v: List<Float>) {
    T(title, 12, bold = true, spacing = 1f); Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        listOf("X", "Y", "Z").forEachIndexed { i, n ->
            Row { T("$n ", 12, Muted, true); T("%.3f".format(v[i]), 13, bold = true, mono = true) }
        }
    }
}

/** DualSense ham jiroskop: 1 °/s = 16 birim (önceki 1024 bölümü kutuyu 64 kat yavaş döndürüyordu). */
const val GYRO_PER_DPS = 16f

/**
 * Kolun yönü (kuaterniyon). Jiroskop entegre edilir, ivmeölçerle yer çekimi yönüne yavaşça düzeltilir
 * (Mahony filtresi) — böylece kutu her yönde 360° döner ve zamanla kaymaz (sapma hariç).
 */
class Orientation {
    @Volatile private var w = 1f; @Volatile private var x = 0f; @Volatile private var y = 0f; @Volatile private var z = 0f
    fun reset() { w = 1f; x = 0f; y = 0f; z = 0f }

    /** gyro: °/s (DualSense ekseni: x eğim, y sapma, z yuvarlanma), accel: ham birim. */
    @Synchronized fun update(gyroDps: FloatArray, accel: FloatArray, dt: Float) {
        var gx = Math.toRadians(gyroDps[0].toDouble()).toFloat(); var gy = Math.toRadians(gyroDps[1].toDouble()).toFloat(); var gz = Math.toRadians(gyroDps[2].toDouble()).toFloat()
        val an = sqrt(accel[0] * accel[0] + accel[1] * accel[1] + accel[2] * accel[2])
        if (an > 1f) {
            val ax = accel[0] / an; val ay = accel[1] / an; val az = accel[2] / an
            // Kuaterniyona göre beklenen "yukarı" (dünya Y) yönü, kol ekseninde.
            val vx = 2 * (x * y + w * z); val vy = w * w - x * x + y * y - z * z; val vz = 2 * (y * z - w * x)
            val ex = ay * vz - az * vy; val ey = az * vx - ax * vz; val ez = ax * vy - ay * vx
            val kp = 2f; gx += kp * ex; gy += kp * ey; gz += kp * ez
        }
        val hw = 0.5f * dt
        val nw = w + (-x * gx - y * gy - z * gz) * hw
        val nx = x + (w * gx + y * gz - z * gy) * hw
        val ny = y + (w * gy - x * gz + z * gx) * hw
        val nz = z + (w * gz + x * gy - y * gx) * hw
        val n = sqrt(nw * nw + nx * nx + ny * ny + nz * nz)
        w = nw / n; x = nx / n; y = ny / n; z = nz / n
    }

    /** Kol → dünya döndürme matrisi (satır düzeni). */
    fun matrix(): FloatArray = floatArrayOf(
        1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y),
        2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x),
        2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y))

    /** Eğim (x), yuvarlanma (z), sapma (y) derece. */
    fun euler(): FloatArray {
        val pitch = Math.toDegrees(asin((2 * (w * x - y * z)).coerceIn(-1f, 1f).toDouble())).toFloat()
        val roll = Math.toDegrees(atan2((2 * (w * z + x * y)).toDouble(), (1 - 2 * (x * x + z * z)).toDouble())).toFloat()
        val yaw = Math.toDegrees(atan2((2 * (w * y + x * z)).toDouble(), (1 - 2 * (x * x + y * y)).toDouble())).toFloat()
        return floatArrayOf(pitch, roll, yaw)
    }
}

@Composable
fun SettingsTab() {
    Title("AYARLAR", "Görünüm")
    Section("Tema", "")
    Panel {
        listOf(false to "Kırmızı", true to "Siyah ve beyaz").forEach { (mono, name) ->
            val on = Themes.mono == mono
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { Themes.set(mono) }.padding(vertical = 12.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                val pal = if (mono) Themes.MONO else Themes.RED
                Box(Modifier.size(34.dp).clip(CircleShape).background(pal.bg).border(2.dp, if (mono) Color(0xFF5A5A5A) else Color.White, CircleShape),
                    contentAlignment = Alignment.Center) { Box(Modifier.size(14.dp).clip(CircleShape).background(pal.card)) }
                Spacer(Modifier.width(14.dp))
                T(name, 16, bold = on, modifier = Modifier.weight(1f))
                if (on) Icon(Icons.Rounded.CheckCircle, null, tint = Color.White)
            }
        }
    }
}

fun modeName(m: TMode) = when (m) {
    TMode.OFF -> "Kapalı"; TMode.RIGID -> "Sert"; TMode.PULSE -> "Darbe"; TMode.FEEDBACK -> "Geri Besleme"; TMode.WEAPON -> "Silah"
    TMode.BOW -> "Yay"; TMode.GALLOP -> "Dörtnala"; TMode.MACHINE -> "Makine"; TMode.VIBRATION -> "Titreşim"
}

/** PS5'teki oyuncu ışık düzenleri (5 LED, ortadaki 3. LED). */
val PLAYERS = listOf("Kapalı" to 0, "1. oyuncu" to 0x04, "2. oyuncu" to 0x0A, "3. oyuncu" to 0x15, "4. oyuncu" to 0x1B)

@Composable
fun PresetMenu(title: String, current: String?, left: Boolean, dismiss: () -> Unit, pick: (Preset) -> Unit) {
    androidx.compose.ui.window.Dialog(onDismissRequest = dismiss) {
        Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).clip(RoundedCornerShape(22.dp)).background(CardC).border(1.dp, Edge, RoundedCornerShape(22.dp))) {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 6.dp, top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                T(title, 17, bold = true, modifier = Modifier.weight(1f))
                IconButton(dismiss) { Icon(Icons.Rounded.Close, "Kapat", tint = Color.White) }
            }
            androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 10.dp), contentPadding = PaddingValues(bottom = 14.dp)) {
                PRESETS.groupBy { it.group }.forEach { (group, list) ->
                    item(key = "g-$group") { T(group.uppercase(), 10, Muted, true, spacing = 1.5f, modifier = Modifier.padding(start = 8.dp, top = 12.dp, bottom = 4.dp)) }
                    list.forEach { p ->
                        item(key = p.name) {
                            val on = current == p.name
                            val cfg = p.forTrigger(left)
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (on) Color.White else Color.Transparent)
                                .clickable { pick(p) }.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    T(p.name, 14, if (on) Color.Black else Color.White, true)
                                    T(modeName(cfg.mode) + (if (!left && p.recoil > 0) " · geri tepme" else ""), 11, if (on) Color(0xFF444444) else Muted)
                                }
                                if (on) Icon(Icons.Rounded.CheckCircle, null, tint = Color.Black, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Çökme olursa nedeni kaydedilir; uygulama bir sonraki açılışta gösterir (geliştiriciye göndermek için). */
object CrashLog {
    fun install(c: Context) {
        val file = java.io.File(c.filesDir, "cokme.txt")
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { file.writeText("Sürüm: ${runCatching { c.packageManager.getPackageInfo(c.packageName, 0).versionName }.getOrNull()}\nİş parçacığı: ${t.name}\n\n" + e.stackTraceToString()) }
            prev?.uncaughtException(t, e)
        }
    }
    fun take(c: Context): String? = java.io.File(c.filesDir, "cokme.txt").takeIf { it.exists() }?.let { f -> f.readText().also { f.delete() } }
}
