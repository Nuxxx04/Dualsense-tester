package com.example.dstester

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Android'in kolun ses aygıtı hakkında gördükleri: [out] çıkış aygıtının adı (yoksa null), [text] ayrıntı satırları. */
data class AudioInfo(val out: String?, val text: String)

/**
 * DualSense USB'ye takılıyken Android'e bir USB ses aygıtı olarak da görünür (hoparlör, 3.5 mm jak, mikrofon).
 * Hangi çıkıştan duyulacağını kolun çıkış raporundaki ses yolu belirler (Output.audioPath).
 *
 * DualSense'in USB ses çıkışı 4 kanallıdır (1-2: kulaklık/hoparlör, 3-4: titreşim motorları). Android bazı
 * telefonlarda aygıtı yalnızca 4 kanal olarak bildirir; bu yüzden ses, aygıtın bildirdiği kanal sayısına göre üretilir.
 */
object DsAudio {
    /** Son çalmanın özeti (ses kola gitti mi, Android başka aygıta mı verdi). */
    @Volatile var lastInfo: String = ""

    private fun isUsb(d: AudioDeviceInfo) = d.type == AudioDeviceInfo.TYPE_USB_HEADSET || d.type == AudioDeviceInfo.TYPE_USB_DEVICE
    private fun isPad(d: AudioDeviceInfo): Boolean {
        val n = d.productName?.toString() ?: ""
        return n.contains("Wireless Controller", true) || n.contains("DualSense", true)
    }
    private fun pick(list: Array<AudioDeviceInfo>): AudioDeviceInfo? {
        val usb = list.filter { isUsb(it) }
        return usb.firstOrNull { isPad(it) } ?: usb.firstOrNull() ?: list.firstOrNull { isPad(it) }
    }

    private fun am(c: Context): AudioManager = c.getSystemService(AudioManager::class.java)
    fun output(c: Context): AudioDeviceInfo? = pick(am(c).getDevices(AudioManager.GET_DEVICES_OUTPUTS))
    fun input(c: Context): AudioDeviceInfo? = pick(am(c).getDevices(AudioManager.GET_DEVICES_INPUTS))
    fun deviceName(c: Context): String? = output(c)?.productName?.toString()

    private fun typeName(t: Int) = when (t) {
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB kulaklık"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB ses"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "telefon hoparlörü"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "ahize"
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "telefon mikrofonu"
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "kablolu kulaklık"
        else -> "tür $t"
    }

    /** Ses aygıtlarını tarar; USB ses aygıtı sonradan göründüğü için ekran bunu aygıt değişince yeniler. */
    fun scan(c: Context): AudioInfo {
        val manager = am(c)
        fun line(p: String, d: AudioDeviceInfo): String {
            val ch = d.channelCounts.joinToString("/").ifEmpty { "?" }
            val hz = d.sampleRates.joinToString("/").ifEmpty { "?" }
            return "$p ${d.productName} · ${typeName(d.type)} · $ch kanal · $hz Hz"
        }
        val outs = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { isUsb(it) || isPad(it) }
        val ins = manager.getDevices(AudioManager.GET_DEVICES_INPUTS).filter { isUsb(it) || isPad(it) }
        val name = output(c)?.productName?.toString()
        val text = if (outs.isEmpty() && ins.isEmpty()) "Android bu kolu bir USB ses aygıtı olarak görmüyor."
        else (outs.map { line("Çıkış:", it) } + ins.map { line("Giriş:", it) }).joinToString("\n")
        return AudioInfo(name, text)
    }

    private fun channelsFor(dev: AudioDeviceInfo, want: Int): Int {
        val cc = dev.channelCounts
        if (cc.isEmpty() || cc.contains(want)) return want
        return cc.filter { it > want }.minOrNull() ?: cc.maxOrNull() ?: want
    }

    private fun rateFor(dev: AudioDeviceInfo): Int {
        val r = dev.sampleRates
        return if (r.isEmpty() || r.contains(48000)) 48000 else (r.maxOrNull() ?: 48000)
    }

    private fun mask(ch: Int) = when (ch) {
        1 -> AudioFormat.CHANNEL_OUT_MONO
        4 -> AudioFormat.CHANNEL_OUT_QUAD
        6 -> AudioFormat.CHANNEL_OUT_5POINT1
        8 -> AudioFormat.CHANNEL_OUT_7POINT1_SURROUND
        else -> AudioFormat.CHANNEL_OUT_STEREO
    }

    /** Kaynak kanal sayısından aygıtın kanal sayısına: ilk iki kanala ses, kalanlara sessizlik. Mono ise iki kanala kopyalanır. */
    private fun remap(src: ShortArray, sc: Int, dc: Int): ShortArray {
        val zero: Short = 0
        val frames = src.size / sc
        val out = ShortArray(frames * dc)
        for (i in 0 until frames) for (k in 0 until dc) {
            out[i * dc + k] = when {
                sc == 1 -> if (k < 2) src[i] else zero
                k < sc -> src[i * sc + k]
                else -> zero
            }
        }
        return out
    }

    /** Medya sesi kısıksa (USB aygıtının ses seviyesi ayrı tutulur) duyulabilir seviyeye çıkarır. */
    private fun raiseVolume(c: Context) {
        try {
            val m = am(c)
            val max = m.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val cur = m.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (cur < max / 2) m.setStreamVolume(AudioManager.STREAM_MUSIC, (max * 0.6).toInt().coerceAtLeast(1), 0)
        } catch (_: Exception) {}
    }

    /** Stereo ton; [left]/[right] hangi kanalda çalacağı. Bitene kadar bekler. */
    fun tone(c: Context, left: Boolean, right: Boolean, ms: Int = 1200, freq: Double = 880.0, sweep: Boolean = false): Boolean {
        val dev = output(c)
        if (dev == null) { lastInfo = "Kolun ses aygıtı Android'de görünmüyor"; return false }
        val ch = channelsFor(dev, 2)
        val rate = rateFor(dev)
        val n = rate * ms / 1000
        val pcm = ShortArray(n * ch)
        var phase = 0.0
        for (i in 0 until n) {
            val f = if (sweep) 300.0 + 1500.0 * i / n else freq
            phase += 2 * PI * f / rate
            val env = minOf(1.0, i / 2000.0, (n - i) / 2000.0)
            val v = (sin(phase) * 0.8 * env * Short.MAX_VALUE).toInt().toShort()
            if (left) pcm[ch * i] = v
            if (right) pcm[ch * i + 1] = v
        }
        return play(c, dev, pcm, rate, ch)
    }

    /** [pcm] [channels] kanallı 16 bit PCM; aygıtın kanal sayısına uyarlanır. Bitene kadar bekler. */
    fun play(c: Context?, dev: AudioDeviceInfo?, pcm: ShortArray, rate: Int, channels: Int): Boolean {
        val ch = if (dev != null) channelsFor(dev, channels) else channels
        val data = if (ch == channels) pcm else remap(pcm, channels, ch)
        var track: AudioTrack? = null
        return try {
            if (c != null) raiseVolume(c)
            val min = AudioTrack.getMinBufferSize(rate, mask(ch), AudioFormat.ENCODING_PCM_16BIT)
            val bufBytes = maxOf(min, rate / 5 * ch * 2) // en az 200 ms
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(mask(ch)).build())
                .setBufferSizeInBytes(bufBytes).setTransferMode(AudioTrack.MODE_STREAM).build()
            track = t
            if (t.state != AudioTrack.STATE_INITIALIZED) { lastInfo = "Ses çıkışı açılamadı ($ch kanal, $rate Hz)"; return false }
            val pinned = if (dev != null) t.setPreferredDevice(dev) else true
            t.setVolume(1f)
            t.play()
            var off = 0
            while (off < data.size) {
                val w = t.write(data, off, minOf(data.size - off, 2400 * ch), AudioTrack.WRITE_BLOCKING)
                if (w <= 0) break
                off += w
            }
            val routed = t.routedDevice
            lastInfo = when {
                dev == null -> "Ses varsayılan çıkışa verildi"
                !pinned -> "Android bu aygıta yönlendirmeyi reddetti: ${dev.productName}"
                routed != null && routed.id != dev.id -> "Dikkat: ses kola gitmedi; Android '${routed.productName}' aygıtına verdi"
                else -> "Ses kola gönderildi: ${dev.productName} · $ch kanal · $rate Hz"
            }
            Thread.sleep(bufBytes / (2L * ch) * 1000L / rate + 150) // tampondaki ses bitsin
            true
        } catch (e: Exception) {
            lastInfo = "Ses hatası: ${e.javaClass.simpleName} ${e.message ?: ""}"
            false
        } finally {
            runCatching { track?.stop() }
            runCatching { track?.release() }
        }
    }

    /** [ms] boyunca kolun mikrofonundan kayıt; her parçada seviye (0..1) bildirir. Kayıt verisini döner. */
    @SuppressLint("MissingPermission")
    fun record(c: Context, ms: Int, level: (Float) -> Unit): ShortArray? {
        val dev = input(c)
        val rate = 48000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(4096)
        val rec = AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.MIC)
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
            .setBufferSizeInBytes(min * 2).build()
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return null }
        if (dev != null) rec.preferredDevice = dev
        val out = ShortArray(rate * ms / 1000); var pos = 0
        val buf = ShortArray(min / 2)
        try {
            rec.startRecording()
            while (pos < out.size) {
                val r = rec.read(buf, 0, minOf(buf.size, out.size - pos)); if (r <= 0) break
                buf.copyInto(out, pos, 0, r); pos += r
                var peak = 0; for (i in 0 until r) peak = maxOf(peak, abs(buf[i].toInt()))
                level(peak / 32768f)
            }
        } finally { runCatching { rec.stop() }; rec.release() }
        return out.copyOf(pos)
    }
}
