package com.example.dstester

import android.view.Choreographer
import android.view.TextureView
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.filament.*
import com.google.android.filament.android.UiHelper
import com.google.android.filament.utils.Manipulator
import com.google.android.filament.utils.ModelViewer
import com.google.android.filament.utils.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

/**
 * Gerçek DualSense modeli (GLB, Filament ile, fiziksel malzeme ve ışık).
 * Kolun yönü her karede modele uygulanır; ışık çubuğu kolun gerçek rengini alır.
 * Filament açılamazsa (eski / desteklenmeyen telefon) [fallback] çizilir.
 *
 * ÇÖKME DÜZELTMESİ: Filament'in ModelViewer'ı, görünüm pencereden ayrılınca (sekme değişince) motoru, modeli
 * ve sahneyi KENDİSİ yok eder. Eski kod ayrıca aynı motoru ikinci kez yok etmeye çalışıyordu (ve ayrılma sırasında
 * son bir kare daha çizmeye kalkıyordu) → yok edilmiş motora erişim → yerel çökme. Şimdi:
 *  - kare döngüsü, ModelViewer'ınkinden ÖNCE kayıtlı bir dinleyiciyle ayrılmadan hemen önce durdurulur,
 *  - ayrılırken Filament nesnelerine hiç dokunulmaz (temizliği ModelViewer yapar).
 */
object Filament3D {
    val ok: Boolean by lazy { runCatching { Utils.init(); true }.getOrDefault(false) }
    /** GLB bir kez okunur, sekmeye her girişte yeniden okunmaz. */
    @Volatile var glb: ByteBuffer? = null
}

@Composable
fun RealGamepad3D(q: Orientation, light: Color, modifier: Modifier, fallback: @Composable () -> Unit) {
    if (!Filament3D.ok) { fallback(); return }
    val context = LocalContext.current
    var bytes by remember { mutableStateOf(Filament3D.glb) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (bytes == null) {
            val b = withContext(Dispatchers.IO) {
                runCatching { context.assets.open("dualsense.glb").use { s -> val raw = s.readBytes(); ByteBuffer.allocateDirect(raw.size).apply { put(raw); rewind() } } }.getOrNull()
            }
            Filament3D.glb = b
            bytes = b
            if (b == null) failed = true
        }
    }
    if (failed) { fallback(); return }
    val lightNow by rememberUpdatedState(light)
    AndroidView(factory = { ctx ->
        val holder = Holder()
        val tv = TextureView(ctx).apply { isOpaque = false }
        // Bu dinleyici ModelViewer'dan ÖNCE eklenir; görünüm ayrılırken önce biz kareleri durdururuz, sonra ModelViewer temizler.
        tv.addOnAttachStateChangeListener(object : android.view.View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: android.view.View) {}
            override fun onViewDetachedFromWindow(v: android.view.View) { holder.stop() }
        })
        val engine = Engine.create()
        val ui = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK).apply { isOpaque = false }
        // Kamera 30° yukarıdan bakar; dokunmayla dönme yok (yön kolun kendisinden gelir).
        val manip = Manipulator.Builder().targetPosition(0f, 0f, 0f).orbitHomePosition(0f, 1.55f, 2.7f).viewport(1, 1).build(Manipulator.Mode.ORBIT)
        val viewer = ModelViewer(tv, engine, ui, manip)
        viewer.view.blendMode = View.BlendMode.TRANSLUCENT
        viewer.renderer.clearOptions = viewer.renderer.clearOptions.apply { clear = true; clearColor = floatArrayOf(0f, 0f, 0f, 0f) }
        viewer.scene.skybox = null
        viewer.scene.indirectLight = IndirectLight.Builder().irradiance(1, floatArrayOf(1f, 1f, 1f)).intensity(28_000f).build(engine)
        // Ek dolgu ışığı (önden)
        val fill = EntityManager.get().create()
        LightManager.Builder(LightManager.Type.DIRECTIONAL).color(1f, 1f, 1f).intensity(60_000f).direction(0.2f, -0.6f, -1f).castShadows(false).build(engine, fill)
        viewer.scene.addEntity(fill)
        holder.viewer = viewer; holder.engine = engine
        tv.tag = holder
        tv
    }, modifier = modifier, update = { tv ->
        val h = tv.tag as? Holder
        val buf = bytes
        val v = h?.viewer
        if (h != null && v != null && h.alive && buf != null && v.asset == null && !h.loading) {
            h.loading = true
            runCatching { v.loadModelGlb(buf.duplicate()) }.onFailure { failed = true }
            h.start(q) { lightNow }
        }
    }, onRelease = { tv -> (tv.tag as? Holder)?.stop() })
}

private class Holder {
    @Volatile var alive = true
    var loading = false
    var viewer: ModelViewer? = null
    var engine: Engine? = null
    private var callback: Choreographer.FrameCallback? = null
    private val transform = FloatArray(16)
    private var lastLight: Color? = null

    fun start(q: Orientation, light: () -> Color) {
        val v = viewer ?: return
        val e = engine ?: return
        val asset = v.asset ?: return
        val box = asset.boundingBox
        val c = box.center; val he = box.halfExtent
        val scale = 2.2f / (2f * maxOf(he[0], he[1], he[2]))
        val cb = object : Choreographer.FrameCallback {
            override fun doFrame(t: Long) {
                if (!alive) return
                Choreographer.getInstance().postFrameCallback(this)
                try {
                    val a = v.asset ?: return
                    // Model eksenini kolun eksenine oturt: 180° y ekseni etrafında (modelde arka +z), ölçekle ve ortala.
                    val m = q.matrix()
                    // R = qMatrix * Ry(180) ; satır düzenini sütun düzenine çevir
                    val r = floatArrayOf(-m[0], m[1], -m[2], -m[3], m[4], -m[5], -m[6], m[7], -m[8])
                    for (col in 0..2) for (row in 0..2) transform[col * 4 + row] = r[row * 3 + col] * scale
                    transform[3] = 0f; transform[7] = 0f; transform[11] = 0f; transform[15] = 1f
                    // öteleme: -R*S*center
                    for (row in 0..2) transform[12 + row] = -(r[row * 3] * c[0] + r[row * 3 + 1] * c[1] + r[row * 3 + 2] * c[2]) * scale
                    val tm = e.transformManager
                    tm.setTransform(tm.getInstance(a.root), transform)
                    val l = light()
                    if (l != lastLight) {
                        lastLight = l
                        a.instance.materialInstances.filter { it.material.name?.contains("Emm", true) == true || it.name?.contains("Emm", true) == true }.forEach { mi ->
                            runCatching { mi.setParameter("baseColorFactor", Colors.RgbaType.SRGB, l.red, l.green, l.blue, 1f) }
                            runCatching { mi.setParameter("emissiveFactor", Colors.RgbType.SRGB, l.red, l.green, l.blue) }
                        }
                    }
                    v.render(t)
                } catch (ex: Exception) { android.util.Log.w("DSTester", "3B çizim", ex) }
            }
        }
        callback = cb
        Choreographer.getInstance().postFrameCallback(cb)
    }

    /** Yalnızca kareleri durdurur; Filament nesnelerine DOKUNMAZ (ModelViewer görünüm ayrılınca hepsini kendisi yok eder). */
    fun stop() {
        alive = false
        callback?.let { Choreographer.getInstance().removeFrameCallback(it) }
        callback = null
    }
}
