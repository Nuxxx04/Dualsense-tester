package com.example.dstester

/**
 * Hazır tetik ayarları. Dokununca L2/R2 bu ayara geçer.
 * recoil: R2 her ateşte kolun motorlarına verilen geri tepme gücü (0 = yok, 255 = en sert).
 * autoMs: basılı tutunca kaç ms'de bir ateş edilir (0 = tek atış, her basışta bir kez).
 */
data class Preset(
    val name: String, val group: String,
    val left: TriggerCfg, val right: TriggerCfg,
    val recoil: Int = 0, val autoMs: Int = 0,
)

val PRESETS = listOf(
    // ---- Silahlar
    Preset("Tabanca", "Silah",
        TriggerCfg(TMode.RIGID, start = 2, strength = 2),
        TriggerCfg(TMode.WEAPON, start = 4, end = 6, strength = 6), recoil = 150),
    Preset("Tüfek (otomatik)", "Silah",
        TriggerCfg(TMode.FEEDBACK, start = 2, strength = 3),
        TriggerCfg(TMode.MACHINE, start = 3, end = 9, strength = 5, freq = 12), recoil = 170, autoMs = 95),
    Preset("Pompalı", "Silah",
        TriggerCfg(TMode.RIGID, start = 3, strength = 4),
        TriggerCfg(TMode.WEAPON, start = 2, end = 7, strength = 8), recoil = 255),
    Preset("Keskin nişancı", "Silah",
        TriggerCfg(TMode.FEEDBACK, start = 1, strength = 6),
        TriggerCfg(TMode.WEAPON, start = 5, end = 8, strength = 8), recoil = 230),
    Preset("SMG (hızlı)", "Silah",
        TriggerCfg(TMode.FEEDBACK, start = 2, strength = 2),
        TriggerCfg(TMode.MACHINE, start = 2, end = 9, strength = 4, freq = 20), recoil = 120, autoMs = 65),
    Preset("Minigun", "Silah",
        TriggerCfg(TMode.RIGID, start = 1, strength = 5),
        TriggerCfg(TMode.VIBRATION, start = 2, strength = 7, freq = 30), recoil = 140, autoMs = 45),
    Preset("Lazer / Plazma", "Silah",
        TriggerCfg(TMode.FEEDBACK, start = 1, strength = 2),
        TriggerCfg(TMode.VIBRATION, start = 3, strength = 4, freq = 80), recoil = 60, autoMs = 120),
    Preset("Tetik teklemesi", "Silah",
        TriggerCfg(TMode.OFF),
        TriggerCfg(TMode.RIGID, start = 0, strength = 8), recoil = 0),
    Preset("Şarjör boş (tık tık)", "Silah",
        TriggerCfg(TMode.OFF),
        TriggerCfg(TMode.PULSE, start = 3, end = 6, strength = 3), recoil = 25),
    Preset("Yay", "Silah",
        TriggerCfg(TMode.FEEDBACK, start = 0, strength = 2),
        TriggerCfg(TMode.BOW, start = 1, end = 6, strength = 7), recoil = 90),
    Preset("El bombası pimi", "Silah",
        TriggerCfg(TMode.OFF),
        TriggerCfg(TMode.WEAPON, start = 6, end = 8, strength = 7), recoil = 40),

    // ---- Araç
    Preset("Gaz ve fren", "Araç",
        TriggerCfg(TMode.FEEDBACK, start = 2, strength = 7),
        TriggerCfg(TMode.FEEDBACK, start = 1, strength = 3)),
    Preset("ABS fren", "Araç",
        TriggerCfg(TMode.VIBRATION, start = 3, strength = 6, freq = 40),
        TriggerCfg(TMode.FEEDBACK, start = 1, strength = 3)),
    Preset("Motor titreşimi", "Araç",
        TriggerCfg(TMode.FEEDBACK, start = 2, strength = 5),
        TriggerCfg(TMode.VIBRATION, start = 1, strength = 3, freq = 60)),
    Preset("Arazi / kum", "Araç",
        TriggerCfg(TMode.GALLOP, start = 2, end = 9, freq = 8),
        TriggerCfg(TMode.GALLOP, start = 1, end = 9, freq = 10)),

    // ---- Diğer
    Preset("At (dörtnala)", "Diğer",
        TriggerCfg(TMode.OFF),
        TriggerCfg(TMode.GALLOP, start = 3, end = 8, freq = 3)),
    Preset("Kılıç / kalkan", "Diğer",
        TriggerCfg(TMode.RIGID, start = 1, strength = 7),
        TriggerCfg(TMode.PULSE, start = 2, end = 5, strength = 6), recoil = 110),
    Preset("Olta çekme", "Diğer",
        TriggerCfg(TMode.OFF),
        TriggerCfg(TMode.VIBRATION, start = 0, strength = 5, freq = 15)),
    Preset("Kapalı", "Diğer", TriggerCfg(TMode.OFF), TriggerCfg(TMode.OFF)),
)

/** Tek tetiğe uygulanacak ayar: araçlarda L2 fren (sol ayar), diğerlerinde ana his (sağ ayar) her iki tetikte de kullanılır. */
fun Preset.forTrigger(left: Boolean): TriggerCfg = if (left && group == "Araç") this.left else right
